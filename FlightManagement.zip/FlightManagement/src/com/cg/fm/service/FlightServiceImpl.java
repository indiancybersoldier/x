package com.cg.fm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fm.bean.FlightBean;
import com.cg.fm.dao.IFlightDao;

@Service
public class FlightServiceImpl implements IFlightService{

	
	@Autowired
	IFlightDao flightDao;
	
	@Override
	public FlightBean deleteFlight(int id) {
		// TODO Auto-generated method stub
		return flightDao.deleteFlight(id);
	}

	@Override
	public List<FlightBean> viewAll() {
		// TODO Auto-generated method stub
		return flightDao.viewAll();
	}

	@Override
	public FlightBean modifyFlight(FlightBean bean) {
		
		return flightDao.modifyFlight(bean);
	}

	@Override
	public FlightBean getFlightDetails(int id) {
		
		return flightDao.getFlightDetails(id);
	}

}
