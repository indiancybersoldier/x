package com.cg.fm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fm.bean.FlightBean;
import com.cg.fm.service.IFlightService;

@Controller
public class FlightController {
	
	@Autowired
	IFlightService flightService;

	@RequestMapping("/viewAll")
	public ModelAndView viewAllTrainee() {
		//System.out.println("allflights");
		List<FlightBean> list = flightService.viewAll();
		ModelAndView mv = new ModelAndView("viewAllFlight");
		mv.addObject("flightlist",list);
		
		return mv;
		
	}

	@RequestMapping("/delete")
	public ModelAndView deleteFlight(@RequestParam("id") int flightId) {

		

		//FlightBean bean = new FlightBean();
		flightService.deleteFlight(flightId);
		List<FlightBean> list = flightService.viewAll();
		ModelAndView mv = new ModelAndView("viewAllFlight");
		mv.addObject("flightlist",list);

		return mv;
	}
	
	@RequestMapping("/find")
	public ModelAndView showModificationForm(@RequestParam("id") int flightId) {

		// Create an attribute of type Question
		FlightBean bean = new FlightBean();
		// Add the attribute to the model and return along with
		// the view name
		bean =flightService.getFlightDetails(flightId);
		ModelAndView mv = new ModelAndView("modifyFlight");
		mv.addObject("bean", bean);
		//mv.addObject("isFirst", "true");

		return mv;
	}

	@RequestMapping("/update")
	public ModelAndView modifyTrainee(@ModelAttribute("bean") FlightBean bean) {

		ModelAndView mv = new ModelAndView();
		/*mv.setViewName("modifyFlight");*/
		
		FlightBean nbean = flightService.modifyFlight(bean);

	
			mv.setViewName("updateSuccess");
			mv.addObject("bean", nbean);
		

		return mv;
	}
}
