package com.cg.fm.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name="flightdetails")
public class FlightBean {
	
	@Id     
	@Column(name="flightid")
	private int flightId;
	
	@Column(name="flightname")
	private String flightname;
	
	
	@Column(name="flightfare")
	private int flightfare;
	
	@Column(name="flightseats")
	private int flightseats;
	
	@Column(name="flightdesc")
	private String flightdescription;
	
	

	public int getFlightId() {
		return flightId;
	}
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}
	public String getFlightname() {
		return flightname;
	}
	public void setFlightname(String flightname) {
		this.flightname = flightname;
	}
	public int getFlightfare() {
		return flightfare;
	}
	public void setFlightfare(int flightfare) {
		this.flightfare = flightfare;
	}
	public int getFlightseats() {
		return flightseats;
	}
	public void setFlightseats(int flightseats) {
		this.flightseats = flightseats;
	}
	public String getFlightdescription() {
		return flightdescription;
	}
	public void setFlightdescription(String flightdescription) {
		this.flightdescription = flightdescription;
	}
	
	
	
	
}
