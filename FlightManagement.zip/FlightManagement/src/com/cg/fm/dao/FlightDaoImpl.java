package com.cg.fm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fm.bean.FlightBean;

@Repository
@Transactional
public class FlightDaoImpl implements IFlightDao{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public FlightBean deleteFlight(int id) {
		FlightBean bean = entityManager.find(FlightBean.class, id);
		if(bean != null)
		{
			
			entityManager.remove(bean);
			
		}
		
			return bean;
	}

	@Override
	public List<FlightBean> viewAll() {
		
		TypedQuery<FlightBean> query = entityManager.createQuery("select fb from FlightBean fb",FlightBean.class);
		List<FlightBean> list = query.getResultList();
		
		return list;
	}

	@Override
	public FlightBean modifyFlight(FlightBean bean) {
		FlightBean newBean = entityManager.merge(bean);
		return newBean;
	}

	@Override
	public FlightBean getFlightDetails(int id) {
		// TODO Auto-generated method stub
		return entityManager.find(FlightBean.class,	id);
	}

}
