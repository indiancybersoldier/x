package com.cg.fm.dao;

import java.util.List;

import com.cg.fm.bean.FlightBean;

public interface IFlightDao {
	
	public FlightBean deleteFlight(int id);
	public List<FlightBean> viewAll();
	public FlightBean modifyFlight(FlightBean bean);
	public FlightBean getFlightDetails(int id);

}
