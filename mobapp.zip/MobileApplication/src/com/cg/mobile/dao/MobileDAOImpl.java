package com.cg.mobile.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import org.junit.Test;

import com.cg.mobile.dto.PurchaseDetailsDTO;
import com.cg.mobile.exception.MobileException;
import com.cg.mobile.util.DBConnection;


public class MobileDAOImpl implements IMobileDAO {
	
	Logger logger=Logger.getRootLogger();
	public MobileDAOImpl(){
		PropertyConfigurator.configure("src//log4j.properties");
	}


	public void DisplayAll() throws MobileException{
		Connection conn1=null;
		PreparedStatement ps1=null;	
		ResultSet rs1=null;
			try {
				DBConnection.getInstance();
				conn1=DBConnection.getConnection();
				
				
				if(conn1==null){
						logger.error("Connection not established");
					}
				
				ps1=conn1.prepareStatement("SELECT mobileid,name,price,quantity FROM mobiles");
				rs1=ps1.executeQuery();
				
				int count=1;
			    
			    System.out.println("SLNO		MOBILEID		NAME		       PRICE		   QUANTITY	");
			    if(rs1==null)
			    	System.out.println("null table");
			    while(rs1.next()){
			    	System.out.println(count+"\t        "+rs1.getInt (1)+"\t                "+rs1.getString (2)+"\t      "+rs1.getFloat (3)+"\t      "+rs1.getInt (4));
				    count++;
				}
			    } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	
	@Test
	public int FetchQuantity(int mobid) throws MobileException {
		Connection conn2=null;
		PreparedStatement ps2=null;	
		ResultSet rs2=null;
		int quantity=0;
		
		DBConnection.getInstance();
		conn2=DBConnection.getConnection();
		
		
		if(conn2==null){
				logger.error("Connection not established");
			}
		
		try {
			ps2=conn2.prepareStatement("SELECT quantity FROM mobiles WHERE mobileid=?");
			ps2.setInt(1,mobid);
			rs2=ps2.executeQuery();
			while(rs2.next()){
			quantity=rs2.getInt(1);}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return quantity;   
	}
	
	public String InsertPurchaseDetails(PurchaseDetailsDTO purchase,int quantity)throws MobileException {
		
		Connection conn3=null;
		PreparedStatement ps3=null;	
		ResultSet rs3=null;
		String purchaseid=null;
		DBConnection.getInstance();
		conn3=DBConnection.getConnection();
		
		
		if(conn3==null){
				logger.error("Connection not established");
			}
		
		try {
			ps3=conn3.prepareStatement("INSERT INTO purchasedetails VALUES(mobileSeq.NEXTVAL,?,?,?,SYSDATE,?)");
		    ps3.setString(1,purchase.getCname());
		    ps3.setString(2,purchase.getMailid());
		    ps3.setString(3,purchase.getPhoneno());
		    ps3.setInt(4,purchase.getMobileid());
		    int rec=ps3.executeUpdate();
		    if(rec>0)
		    {
		    System.out.println("PURCHASE RECORD DETAILS SAVED SUCCESSFULLY");
		    ps3=conn3.prepareStatement("Select mobileSeq.CURRVAL FROM DUAL");
		    rs3=ps3.executeQuery();
		    while(rs3.next()){
				purchaseid=rs3.getString(1);}
		    
		    quantity=quantity-1;
		    ps3=conn3.prepareStatement("UPDATE mobiles SET quantity=? WHERE mobileid=?");
		    ps3.setInt(1, quantity);
		    ps3.setInt(2, purchase.getMobileid());
		    int res=ps3.executeUpdate();
		    if(res>0){
		    	System.out.println("Quantity UPDATED SUCCESSFULLY");
		    	logger.info("Insertion successful"+res+" no of records updated");
		    }
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return purchaseid;
		
		
	}
	
	public void DeleteMobile(int mobileid)throws MobileException{
		Connection conn4=null;
		PreparedStatement ps4=null;	
		DBConnection.getInstance();
		conn4=DBConnection.getConnection();
		
		if(conn4==null){
				logger.error("Connection not established");
			}
		
		try {
			ps4=conn4.prepareStatement("DELETE FROM mobiles WHERE mobileid=?");
			ps4.setInt(1, mobileid);
			int res=ps4.executeUpdate();
			if(res>0)
				System.out.println("MOBILE DELETED SUCCESSFULLY");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	 public void SearchMobiles(int price1,int price2)throws MobileException{
		 Connection conn5=null;
			PreparedStatement ps5=null;	
			ResultSet rs5=null;
			DBConnection.getInstance();
			conn5=DBConnection.getConnection();
			
			
			if(conn5==null){
					logger.error("Connection not established");
				}
			
			try {
				ps5=conn5.prepareStatement("SELECT mobileid,name,price,quantity FROM mobiles WHERE price BETWEEN ? AND ?");
				ps5.setInt(1, price1);
				ps5.setInt(2, price2);
				rs5=ps5.executeQuery();		
                int count=1;
			    
			    System.out.println("SLNO		MOBILEID		NAME		PRICE		QUANTITY	");
			    if(rs5==null)
			    	System.out.println("null table");
			    while(rs5.next()){
			    	System.out.println(count+"\t"+rs5.getInt (1)+"\t"+rs5.getString (2)+"\t"+rs5.getFloat (3)+"\t"+rs5.getInt (4));
				    count++;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	 }
}