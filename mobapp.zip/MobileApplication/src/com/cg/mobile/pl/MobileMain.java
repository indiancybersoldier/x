package com.cg.mobile.pl;

import java.util.Scanner;



import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobile.dto.PurchaseDetailsDTO;
import com.cg.mobile.exception.MobileException;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.MobileServiceImpl;

public class MobileMain {
	
	
	public static void main(String[] args) {
		
		Logger logger=Logger.getRootLogger();
		PropertyConfigurator.configure("src//log4j.properties");
		
		Scanner sc=new Scanner(System.in);
		IMobileService mobileservice=null;
		String ch;
		int choice;
		do{
			System.out.println("1.VIEW ALL MOBILE DETAILS");
			System.out.println("2.PURCHASE");
			System.out.println("3.DELETE A MOBILE DETAIL");
			System.out.println("4.SEARCH MOBILE BASED ON PRICE");
			System.out.println("5.EXIT");
			System.out.println("ENTER YOUR CHOICE");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:mobileservice=new MobileServiceImpl();
				   try {
					mobileservice.DisplayAll();
				} catch (MobileException e) {
					logger.error("exception occured", e);
					e.printStackTrace();
				}
			       break;
			case 2:mobileservice=new MobileServiceImpl();
			        System.out.println("ENTER THE MOBILE YOU WANT TO PURCHASE");
			      
			       int quantity;
				try {
					 int mobid=sc.nextInt();
				    mobileservice=new MobileServiceImpl();
					quantity = mobileservice.FetchQuantity(mobid);
					PurchaseDetailsDTO purchase=new PurchaseDetailsDTO(); 
					if(quantity>0)
					{
						
						System.out.println("Enter customer name");
						String name=sc.next();
						System.out.println("Enter mailid");
						String mailid=sc.next();
						System.out.println("Enter phone number");
						String pno=sc.next();
						
					
						purchase.setCname(name);
						purchase.setMailid(mailid);
						purchase.setPhoneno(pno);
						purchase.setMobileid(mobid);
						
						String purchaseid;
						if(mobileservice.isvalid(purchase))
						{
							purchaseid=mobileservice.InsertPurchaseDetails(purchase,quantity);
							System.out.println("**YOUR PURCHASE ID IS "+purchaseid+"  **");
						}
					}
						
				} catch (MobileException e) {
					logger.error("exception occured", e);
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			       
				break;
			case 3: mobileservice=new MobileServiceImpl();
					System.out.println("Enter the mobile id to be deleted");
					int mobileid=sc.nextInt();
				try {
					mobileservice.DeleteMobile(mobileid);
				} catch (MobileException e) {
					logger.error("exception occured",e);
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
					break;//call delete function
			case 4:mobileservice=new MobileServiceImpl();
					System.out.println("Enter the range of price you want to search");
					int price1=sc.nextInt();
					int price2=sc.nextInt();
				try {
					mobileservice.SearchMobiles(price1,price2);
				} catch (MobileException e) {
					logger.error("exception occured",e);
					// TODO Auto-generated catch block
					e.printStackTrace();
				}break;//call search function
			case 5:System.exit(0);
			}
			System.out.println("DO YOU WANT TO CONTINUE IF YES ENTER Y ELSE ENTER N");
			ch=sc.next();
			}while(ch.equals("y")||ch.equals("Y"));
		}

	}


