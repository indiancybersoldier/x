package com.cg.mobile.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mobile.dao.IMobileDAO;
import com.cg.mobile.dao.MobileDAOImpl;
import com.cg.mobile.dto.PurchaseDetailsDTO;
import com.cg.mobile.exception.MobileException;



public class MobileServiceImpl implements IMobileService{

	
	public void DisplayAll() throws MobileException {
		IMobileDAO mobileDao=new MobileDAOImpl();
		mobileDao.DisplayAll();
		
	}

	
	public int FetchQuantity(int mobid) throws MobileException{
	    IMobileDAO mobileDao=new MobileDAOImpl();
		int quant=mobileDao.FetchQuantity(mobid);
		return quant;
	}
	
	public boolean isvalid(PurchaseDetailsDTO obj) throws MobileException
	{
		Pattern pattern1=Pattern.compile("^[A-Z][a-z]{0,19}$");
		String name=obj.getCname();
		Matcher matcher1=pattern1.matcher(name);
		
		if(!matcher1.find())
		 throw new MobileException("Problem in CUSTOMER NAME");
		
		
		Pattern pattern2=Pattern.compile("^[a-zA-Z0-9]*[.]?[a-zA-Z]*[@][a-zA-Z]+[.][a-zA-Z]+$");
		String mailid=obj.getMailid();
		Matcher matcher2=pattern2.matcher(mailid);
		
		if(!matcher2.find())
		 throw new MobileException("Problem in EMAIL ID");
		
		Pattern pattern3=Pattern.compile("^[0-9]{10}$");
		String phno=obj.getPhoneno();
		Matcher matcher3=pattern3.matcher(phno);
		
		if(!matcher3.find())
		 throw new MobileException("Problem in PHONE NUMBER");
		
		Pattern pattern4=Pattern.compile("^[0-9]{4}$");
		String MID=Integer.toString(obj.getMobileid());
		Matcher matcher4=pattern4.matcher(MID);
		
		if(!matcher4.find())
		 throw new MobileException("Problem in MOBILEID");
		
		return true;
	}


	
	public String InsertPurchaseDetails(PurchaseDetailsDTO purchase,int quantity)throws MobileException {
		    IMobileDAO mobileDao=new MobileDAOImpl();
			String purchaseid=mobileDao.InsertPurchaseDetails(purchase,quantity);
			return purchaseid;
		
	}
	
	public void DeleteMobile(int mobileid)throws MobileException{
		  IMobileDAO mobileDao=new MobileDAOImpl();
		  mobileDao.DeleteMobile(mobileid);
	}

	 public void SearchMobiles(int price1,int price2)throws MobileException{
		 IMobileDAO mobileDao=new MobileDAOImpl();
		 mobileDao.SearchMobiles(price1,price2);
	 }
	



}



