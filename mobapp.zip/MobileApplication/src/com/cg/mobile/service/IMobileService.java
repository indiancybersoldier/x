package com.cg.mobile.service;

import com.cg.mobile.dto.PurchaseDetailsDTO;
import com.cg.mobile.exception.MobileException;

public interface IMobileService {
	public void DisplayAll()throws MobileException;
    public int FetchQuantity(int mobid)throws MobileException;
    public boolean isvalid(PurchaseDetailsDTO obj)throws MobileException;
    public String InsertPurchaseDetails(PurchaseDetailsDTO obj,int quantity)throws MobileException;
    public void DeleteMobile(int mobileid)throws MobileException;
    public void SearchMobiles(int price1,int price2)throws MobileException;
}
