package com.cg.mobile.dto;

import java.time.LocalDate;



public class PurchaseDetailsDTO {

	int purchaseid;
	String cname;
	String mailid;
	String phoneno;
	LocalDate date;
	int mobileid;
	public PurchaseDetailsDTO(){}
	public PurchaseDetailsDTO(int purchaseid, String cname, String mailid,
			String phoneno, LocalDate date, int mobileid) {
		super();
		this.purchaseid = purchaseid;
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.date = date;
		this.mobileid = mobileid;
	}
	public int getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	
	
}
