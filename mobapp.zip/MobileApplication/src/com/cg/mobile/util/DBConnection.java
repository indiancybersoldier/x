package com.cg.mobile.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.mobile.exception.MobileException;



public class DBConnection {
	private static Connection connection=null;
	private static DBConnection instance=null;
	private DBConnection(){
			
	}
	
	public static DBConnection getInstance(){
		if(instance==null)
			instance=new DBConnection();
		return instance;
	}
	
	public  static Connection getConnection() throws MobileException{
		
	   if(connection==null){
		try
		{
			
			String fileName="dbConnection.properties";
			Properties prop=new Properties();
			InputStream inputStream =new FileInputStream(fileName);
			prop.load(inputStream);
		    inputStream.close();
		    String connectionURL = prop.getProperty("jdbc.url");
		    String username = prop.getProperty("jdbc.user");
		    String password = prop.getProperty("jdbc.password");
		    connection=DriverManager.getConnection(connectionURL,username,password);
		     
			
		}
		
		
		
		catch(SQLException e)
		{
			//System.out.println();
			throw new MobileException("PLEASE CHECK THE ORACLE LOGIN CREDENTIALS "+e);
		}
		
		catch(Exception e)
		{
			throw new MobileException("message from DB/Class:"+e.getMessage());
		}

	   }
return connection;

	}
}

