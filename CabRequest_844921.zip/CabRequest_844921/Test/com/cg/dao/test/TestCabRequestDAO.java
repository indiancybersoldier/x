package com.cg.dao.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.cg.cab.dao.CabRequestDAOImpl;
import com.cg.cab.exceptions.CabRequestException;
import com.cg.cabs.bean.CabRequestBean;



public class TestCabRequestDAO {
	CabRequestDAOImpl cabRequestDAO = null;
	CabRequestBean cabRequestBean = null;
	
	@Before
	public void setBefore()
	{
		cabRequestBean = new CabRequestBean( "Harshita",
				 "1234567890", "17-MAY-16", "Accepted",
				 "MH VS 2345", "bangalore","400096");
		cabRequestDAO = new CabRequestDAOImpl();
		
	}
	@Test
	public void testValidate() throws CabRequestException 
	{
		
		assertTrue(cabRequestDAO.addCabRequestDetails(cabRequestBean)>100001);
		
	}
	@Test
	public void testinfo() throws CabRequestException
	{
		assertEquals(1,(cabRequestDAO.getRequestDetails(100003)).size());
	}

	

}
