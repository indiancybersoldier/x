package com.cg.cabs.bean;

public class CabRequestBean {
private int request_id=0;
private String cname=null;
private String ph_no=null;

public CabRequestBean(){
	
}

public CabRequestBean(String cname, String ph_no, String date_request,
		String request_status, String cab_number, String address_of_pickup,
		String pincode) {
	super();
	this.cname = cname;
	this.ph_no = ph_no;
	this.date_request = date_request;
	this.request_status = request_status;
	this.cab_number = cab_number;
	this.address_of_pickup = address_of_pickup;
	this.pincode = pincode;
}
private String date_request=null;
private String request_status=null;
public int getRequest_id() {
	return request_id;
}
public void setRequest_id(int request_id) {
	this.request_id = request_id;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getPh_no() {
	return ph_no;
}
public void setPh_no(String ph_no) {
	this.ph_no = ph_no;
}
public String getDate_request() {
	return date_request;
}
public void setDate_request(String date_request) {
	this.date_request = date_request;
}
public String getRequest_status() {
	return request_status;
}
public void setRequest_status(String request_status) {
	this.request_status = request_status;
}
public String getCab_number() {
	return cab_number;
}
public void setCab_number(String cab_number) {
	this.cab_number = cab_number;
}
public String getAddress_of_pickup() {
	return address_of_pickup;
}
public void setAddress_of_pickup(String address_of_pickup) {
	this.address_of_pickup = address_of_pickup;
}
public String getPincode() {
	return pincode;
}
public void setPincode(String pincode) {
	this.pincode = pincode;
}
private String cab_number=null;
private String address_of_pickup=null;
private String pincode=null;
}
