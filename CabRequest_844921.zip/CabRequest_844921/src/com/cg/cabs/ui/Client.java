package com.cg.cabs.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.cab.exceptions.CabRequestException;
import com.cg.cab.service.CabServiceImpl;
import com.cg.cabs.bean.CabRequestBean;



public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Logger logger=Logger.getRootLogger();
		PropertyConfigurator.configure("resources//log4j.properties");
		
		CabRequestBean cabRequestBean = null;
		cabRequestBean = new CabRequestBean();
		CabServiceImpl cabService = null;
		cabService = new CabServiceImpl();
		int option = 0;
		String cname=null;
		String ph_no=null;
		String address_of_pickup=null;
		String pincode=null;
		int requestId=0;
		Scanner input = new Scanner(System.in);
		while(option!=4){
			System.out.println("Welcome to Cab Service Application");
			System.out.println("Choose from the below options");
			System.out.println("1.Raise Cab Request");
			System.out.println("2.View Cab Request Status");
			System.out.println("3.Exit");
			option = input.nextInt();
			
			//selecting the option from menu
			switch(option){
					//Accepting Customer details
			case 1:System.out.println("Enter the Customer name");
					cname = input.next();
					cabRequestBean.setCname(cname);
					
					System.out.println("Enter the phone number");
					ph_no=input.next();
					cabRequestBean.setPh_no(ph_no);
					
					System.out.println("Enter the Address of Pickup");		
					address_of_pickup = input.next();
					cabRequestBean.setAddress_of_pickup(address_of_pickup);
					
					System.out.println("Enter the Pin code");
					pincode=input.next();
					cabRequestBean.setPincode(pincode);
					
					try{
					cabService.validateDetails(cabRequestBean);
					cabService.getCabNumber(pincode, cabRequestBean);
					int request_id = cabService.addCabRequestDetails(cabRequestBean);
					System.out.println("Your Cab Request has been successfully registered,your request ID  is = "+request_id);
					}
					catch(CabRequestException e){
						System.out.println(e.getMessage());
					}
					break;
					
					//Displaying the details with reference to request id
			case 2:System.out.println("Enter the request ID");
					requestId = input.nextInt();
					
					cabRequestBean.setRequest_id(requestId);
					try{
						List<CabRequestBean> custList=new ArrayList<CabRequestBean>();
						custList=cabService.getRequestDetails(requestId);
						print(custList);
					}
					catch(CabRequestException e){
						System.out.println(e.getMessage());
					}
					break;
					
			case 3:	System.out.println("Thank you visit again!");
					System.exit(0);
					break;
			default: System.out.println("Please enter a valid option");
			}
		}
		

	}
	//To print the details
	private static void print(List<CabRequestBean> custList){
		for(CabRequestBean cust:custList)
		{
			System.out.println("Name of the Customer: "+cust.getCname());
			System.out.println("Request Status: "+cust.getRequest_status());
			System.out.println("Cab Number: "+cust.getCab_number());
			System.out.println("------------");
		}
	}

}
