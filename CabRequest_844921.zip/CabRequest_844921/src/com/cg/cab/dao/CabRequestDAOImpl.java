package com.cg.cab.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.cab.exceptions.CabRequestException;
import com.cg.cab.util.DBConnection;
import com.cg.cabs.bean.CabRequestBean;

public class CabRequestDAOImpl implements ICabRequestDAO{
	Logger logger=Logger.getRootLogger();
	public CabRequestDAOImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	/*******************************************************************************************************
	 - Function Name	:	addCabRequestDetails(CabRequestBean cabRequestBean)
	 - Input Parameters	:	CabRequestBean cabRequestBean
	 - Return Type		:	int
	 - Throws			:  	CabRequestException
	 - Author			:	xxxxxxxx
	 - Creation Date	:	17/05/2016
	 - Description		:	Adding customer detail
	 ********************************************************************************************************/

	@Override
	public int addCabRequestDetails(CabRequestBean cabRequestBean) throws CabRequestException {
		// TODO Auto-generated method stub
			PreparedStatement pst;
			ResultSet rs = null;
			int request_id=0;
			Connection conn = DBConnection.getDBConnection().getConnection();
			try	{
				if(conn!=null) {
					pst = conn.prepareStatement(IQueryMapper.INSERT_QUERY);
					pst.setString(1, cabRequestBean.getCname());
					pst.setString(2, cabRequestBean.getPh_no());
					pst.setString(3, cabRequestBean.getRequest_status());
					pst.setString(4,cabRequestBean.getCab_number());
					pst.setString(5, cabRequestBean.getAddress_of_pickup());
					pst.setString(6, cabRequestBean.getPincode());
					pst.executeQuery();
					pst=conn.prepareStatement(IQueryMapper.REQUEST_ID);
					 rs=pst.executeQuery();
					 	if(rs.next())
							{
							request_id=rs.getInt(1);
							logger.info("Request id generated");
									
							}
					}
			}

			catch(SQLException e){
				logger.error(e.getMessage());
				throw new CabRequestException(e.getMessage());
			}
			finally
			{
				try 
				{
					conn.close();
				} 
				catch (SQLException e) 
				{
					logger.error(e.getMessage());
					throw new CabRequestException("Error in closing db connection");

				}
			}
			
			return request_id;
	}

	/*******************************************************************************************************
	 - Function Name	:	getRequestDetails(int requestId)
	 - Input Parameters	:	requestid
	 - Return Type		:	List
	 - Throws			:  	CabRequestException
	 - Author			:	xxxxxxx
	 - Creation Date	:	17/05/2016
	 ********************************************************************************************************/
	@Override
	public List<CabRequestBean> getRequestDetails(int requestId)
			throws CabRequestException {
		// TODO Auto-generated method stub
		List<CabRequestBean> custList=new ArrayList<CabRequestBean>();
		Connection conn;
		conn= DBConnection.getDBConnection().getConnection();
		PreparedStatement pst;
		ResultSet rs= null;
		CabRequestBean cabRequestBean =null;
		
		try{
			
			
			if(conn!=null){
				cabRequestBean = new CabRequestBean();
				pst = conn.prepareStatement(IQueryMapper.FETCH_DETAIL);
				pst.setInt(1, requestId);
				rs = pst.executeQuery();
				while(rs.next()){
					cabRequestBean = new CabRequestBean(); 
					cabRequestBean.setCname(rs.getString(1));
					cabRequestBean.setRequest_status(rs.getString(2));
					cabRequestBean.setCab_number(rs.getString(3));
					custList.add(cabRequestBean);
					logger.info("Records fetched successfully");
				}
			}
	}
		catch(SQLException e){
			logger.error(e.getMessage());
			throw new CabRequestException(e.getMessage());
		}
		finally
		{
			try 
			{
				conn.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CabRequestException("Error in closing db connection");

			}
		}
		return custList;
}
}
