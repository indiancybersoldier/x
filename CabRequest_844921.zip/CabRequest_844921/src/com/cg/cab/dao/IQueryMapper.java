package com.cg.cab.dao;

public interface IQueryMapper {
	public static final String INSERT_QUERY="INSERT INTO cab_request VALUES (cabrequest.nextval,?,?,SYSDATE,?,?,?,?)";
	public static final String REQUEST_ID="SELECT cabrequest.CURRVAL FROM DUAL";
	public static final String FETCH_DETAIL="SELECT customer_name,request_status,cab_number FROM cab_request WHERE request_id=?";
}
