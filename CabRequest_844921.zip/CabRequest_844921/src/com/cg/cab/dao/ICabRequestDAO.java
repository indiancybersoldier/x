package com.cg.cab.dao;

import java.util.List;

import com.cg.cab.exceptions.CabRequestException;
import com.cg.cabs.bean.CabRequestBean;

public interface ICabRequestDAO {
	public int addCabRequestDetails(CabRequestBean cabRequestBean) throws CabRequestException; 
	//public List<CabRequestBean> getRequestDetails(String requestId) throws CabRequestException;
	public List<CabRequestBean> getRequestDetails(int requestId)
			throws CabRequestException;
}
