package com.cg.cab.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.cab.dao.CabRequestDAOImpl;
import com.cg.cab.exceptions.CabRequestException;
import com.cg.cabs.bean.CabRequestBean;


public class CabServiceImpl implements ICabService{

	CabRequestDAOImpl cabRequestDAO =  new CabRequestDAOImpl();
	/*******************************************************************************************************
	 - Function Name	:	validateDetails
	 - Input Parameters	:	cabRequest object
	 - Throws			:  	CabRequestException
	 - Author			:	xxxxxxxxx
	 - Creation Date	:	17/05/2016
	 - Description		:	validating the details of the customer 
	 ********************************************************************************************************/
	@Override
	public void validateDetails(CabRequestBean cabRequestBean) throws CabRequestException {
		// TODO Auto-generated method stub
		String cname = cabRequestBean.getCname();
		String phno = cabRequestBean.getPh_no();
		String address_of_pickup = cabRequestBean.getAddress_of_pickup();
		String pincode = cabRequestBean.getPincode();
		
		Pattern name = Pattern.compile("^[a-zA-z ]{3,}$");
		Matcher m1 = name.matcher(cname);
		if (!(m1.matches())) {
			throw new CabRequestException("Customer name should be in alphabets");
		}
		Pattern number = Pattern.compile("^[0-9]{10}$");
		Matcher m2 = number.matcher(phno);
		if(!(m2.matches())){
			throw new CabRequestException("Phone number should contain ten numbers only");
		}
		Pattern num = Pattern.compile("^[0-9]{6}$");
		Matcher m3 = num.matcher(pincode);
		if(!(m3.matches())){
			throw new CabRequestException("Pincode must be six digits");
		}
		
	}
	
	/*******************************************************************************************************
	 - Function Name	:	getCabNumber
	 - Input Parameters	:	pincode,cabRequest object
	 - Throws			:  	CabRequestException
	 - Author			:	xxxxxxxxxx
	 - Creation Date	:	17/05/2016
	 ********************************************************************************************************/
	
	public void getCabNumber(String pincode,CabRequestBean cabRequestBean) throws CabRequestException{
		String request_status=null;
		String cab_number[][]={
				{"400096","MH VS 2345"},
				{"411026","MH VH 34567"},
				{"411013","MH AN 97886"},
				{"560066","MH AS 875"},
				{"382009","MH KN 9856"},
				{"400708","MH TF 8956"}
				
	};
		int len=cab_number.length;
		for(int index=0;index<len;index++){
			if(cab_number[index][0].equals(pincode))
			{
				cabRequestBean.setCab_number(cab_number[index][1]);
				cabRequestBean.setRequest_status("Accepted");
 		}
		else{
			cabRequestBean.setCab_number("null");
			
			cabRequestBean.setRequest_status("Not Accepted");
			}
		}

	}
	/*******************************************************************************************************
	 - Function Name	:	addCabRequestDetails
	 - Input Parameters	:	cabRequest object
	 - Throws			:  	CabRequestException
	 - Author			:	xxxxxxxx
	 - Creation Date	:	17/05/2016
	 - Description		:	adding customer details to database 
	 ********************************************************************************************************/
	@Override
	public int addCabRequestDetails(CabRequestBean cabRequestBean) throws CabRequestException {
		// TODO Auto-generated method stub
		int request_id = cabRequestDAO.addCabRequestDetails(cabRequestBean);
		return request_id;
	}

	/*******************************************************************************************************
	 - Function Name	:	getRequestDeatils
	 - Input Parameters	:	requestId
	 - Throws			:  	CabRequestException
	 - Author			:	xxxxxxxx
	 - Creation Date	:	17/05/2016
	 ********************************************************************************************************/
	@Override
	public List<CabRequestBean> getRequestDetails(int requestId) throws CabRequestException {
		
		// TODO Auto-generated method stub
		List<CabRequestBean> custList=new ArrayList<CabRequestBean>();
		custList= cabRequestDAO.getRequestDetails(requestId);
		return custList;
		
	}

	
}