package com.cg.cab.service;

import java.util.List;

import com.cg.cab.exceptions.CabRequestException;
import com.cg.cabs.bean.CabRequestBean;

public interface ICabService {
		public void validateDetails(CabRequestBean cabRequestBean) throws CabRequestException;
		public void getCabNumber(String pincode,CabRequestBean cabRequestBean) throws CabRequestException;
		public int addCabRequestDetails(CabRequestBean cabRequestBean) throws CabRequestException; 
		//public List<CabRequestBean> getRequestDetails(String requestId) throws CabRequestException;
		List<CabRequestBean> getRequestDetails(int requestId)
				throws CabRequestException;
}
