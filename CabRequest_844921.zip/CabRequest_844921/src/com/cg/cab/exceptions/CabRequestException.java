package com.cg.cab.exceptions;

public class CabRequestException extends Exception {
	public CabRequestException(String message) 
	{
		
		super(message);
	}

}
