package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hbms.bean.Booked;
import com.cg.hbms.bean.HBMSBean;
import com.cg.hbms.bean.HBMSBooking;
import com.cg.hbms.bean.HBMSGuest;
import com.cg.hbms.bean.HBMSHotel;
import com.cg.hbms.bean.HBMSRoom;
import com.cg.hbms.exception.HBMSException;
import com.cg.hbms.util.DBConnection;



public class HBMSDAOImpl implements HBMSDAO{

	Logger logger=Logger.getRootLogger();
	
	
	public HBMSDAOImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	@Override
	public void registerCustomer(HBMSBean hbmsbean) throws HBMSException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try{
			preparedStatement=con.prepareStatement(QuerryMapper.Insert_Querry);
			preparedStatement.setString(1, hbmsbean.getUser_id());
			preparedStatement.setString(2, hbmsbean.getPass());
			preparedStatement.setString(3, hbmsbean.getUser_name());
			preparedStatement.setString(4, hbmsbean.getMobileno());
			preparedStatement.setString(5, hbmsbean.getPhone());
			preparedStatement.setString(6, hbmsbean.getAddress());
			preparedStatement.setString(7, hbmsbean.getEmail());
			preparedStatement.executeUpdate();
		}
		catch(SQLException e){
			logger.error("Insertion failed "+e);
			throw new HBMSException(e.getMessage());
		}
	}

	@Override
	public String login(HBMSBean hbmsbean) throws HBMSException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try{
			String role="";
			preparedStatement=con.prepareStatement(QuerryMapper.Valid_Login);
			preparedStatement.setString(1, hbmsbean.getUser_id());
			preparedStatement.setString(2, hbmsbean.getPass());
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				role=resultSet.getString(1);
			}
			return role;
		}
		catch(SQLException e)
		{
			logger.info("Unauthentic user ");
			throw new HBMSException("Sorry You are not Registered with us");
		}
		
	}

	@Override
	public void addHotel(HBMSHotel hbmshotel) throws HBMSException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		try{
			preparedStatement=con.prepareStatement(QuerryMapper.Insert_Hotel);
			preparedStatement.setString(1, hbmshotel.getHotel_id());
			preparedStatement.setString(2, hbmshotel.getCity());
			preparedStatement.setString(3, hbmshotel.getHotel_name());
			preparedStatement.setString(4, hbmshotel.getAddress());
			preparedStatement.setString(5, hbmshotel.getDescription());
			preparedStatement.setDouble(6, hbmshotel.getRate());
			preparedStatement.setString(7, hbmshotel.getMobileno());
			preparedStatement.setString(8, hbmshotel.getPhone());
			preparedStatement.setString(9, hbmshotel.getRating());
			preparedStatement.setString(10, hbmshotel.getEmail());
			preparedStatement.setString(11, hbmshotel.getFax());
			preparedStatement.executeUpdate();
		}
		catch(SQLException e){
			logger.error("Insertion failed "+e);
		throw new HBMSException(e.getMessage());
		}
	}

	@Override
	public List<HBMSHotel> getAllHotelDetails() throws HBMSException {
		// TODO Auto-generated method stub
	
		List<HBMSHotel> List = new ArrayList<HBMSHotel>();
		HBMSHotel hbmshotel = new HBMSHotel();
		
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		try {
			preparedStatement=con.prepareStatement(QuerryMapper.VIEW_HOTELS);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()){
				hbmshotel.setHotel_id(resultSet.getString(1));	
				hbmshotel.setHotel_name(resultSet.getString(2));
				hbmshotel.setCity(resultSet.getString(3));
				
				List.add(hbmshotel);
				hbmshotel = new HBMSHotel();
			}
			
		} catch (SQLException e) {
			// TODO: handle exception
			
			logger.error("sql ERROR "+e);
			throw new HBMSException("dao/sql/ERROR:" 
					+ e.getMessage());
			
		}catch (Exception e) {
			
			logger.error("eXCEPTION "+e);
			
		}
		
		return List;
	}

	
	@Override
	public List<HBMSBooking> getBookingDetails() throws HBMSException {
		// TODO Auto-generated method stub
		List<HBMSBooking> List = new ArrayList<HBMSBooking>();
		HBMSBooking hbmsbooking = new HBMSBooking();
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement=con.prepareStatement(QuerryMapper.VIEW_BOOKINGS);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()){
				hbmsbooking.setBooking_id(resultSet.getString(1));
				hbmsbooking.setRoom_id(resultSet.getString(2));
				
				List.add(hbmsbooking);
				hbmsbooking = new HBMSBooking();
				
			}
			
		} catch (SQLException e) {
			// TODO: handle exception
			logger.error("Insertion failed ");
			//e.printStackTrace();
			throw new HBMSException("dao/sql/ERROR:" 
					+ e.getMessage());
		}
		
		return List;
	}

	@Override
	public List<HBMSBooking> getHotelDetails() throws HBMSException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void updatedes(String hotelid, String des) throws HBMSException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		int queryRes=0;
		try{
			preparedStatement=con.prepareStatement(QuerryMapper.Update_Des);
			preparedStatement.setString(1, des);
			preparedStatement.setString(2, hotelid);
			queryRes=preparedStatement.executeUpdate();
			if(queryRes==0)
			{
				throw new HBMSException("Please Enter Correct Hotel Id");
			}
		}
		catch(SQLException e){
			logger.error("Insertion failed "+e);
			throw new HBMSException(e.getMessage());
		}
	}

	@Override
	public List<HBMSHotel> searchHotel(String search) throws HBMSException {
		// TODO Auto-generated method stub
		List<HBMSHotel> List = new ArrayList<HBMSHotel>();
		HBMSHotel hbmssearch = new HBMSHotel();
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement=con.prepareStatement(QuerryMapper.Search_hotels);
			preparedStatement.setString(1, search);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				hbmssearch.setHotel_id(resultSet.getString(1));
				hbmssearch.setCity(resultSet.getString(2));
				hbmssearch.setHotel_name(resultSet.getString(3));
				hbmssearch.setAddress(resultSet.getString(4));
				hbmssearch.setDescription(resultSet.getString(5));
				hbmssearch.setRate(resultSet.getDouble(6));
				hbmssearch.setMobileno(resultSet.getString(7));
				hbmssearch.setPhone(resultSet.getString(8));
				hbmssearch.setRating(resultSet.getString(9));
				hbmssearch.setEmail(resultSet.getString(10));
				hbmssearch.setFax(resultSet.getString(11));
				List.add(hbmssearch);
				hbmssearch=new HBMSHotel();
			}
		}
		catch(SQLException e){
			logger.error("Insertion failed ");
			throw new HBMSException(e.getMessage());
		}
		return List;
	}

	@Override
	public List<HBMSHotel> getAllHotelCity() throws HBMSException {
		// TODO Auto-generated method stub
		List<HBMSHotel> List = new ArrayList<HBMSHotel>();
		HBMSHotel hbmssearch = new HBMSHotel();
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement=con.prepareStatement(QuerryMapper.View_HotelByCity);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				hbmssearch.setCity(resultSet.getString(1));
				List.add(hbmssearch);
				hbmssearch=new HBMSHotel();
			}
		}
		catch(SQLException e)
		{
			logger.error("Insertion failed SQL error ");
			throw new HBMSException(e.getMessage());
		}
		return List;
	}

	@Override
	public List<HBMSHotel> searchHotelById(String hotelBook) throws HBMSException{
		// TODO Auto-generated method stub
		List<HBMSHotel> List = new ArrayList<HBMSHotel>();
		HBMSHotel hbmssearch = new HBMSHotel();
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;

		try {
			preparedStatement=con.prepareStatement(QuerryMapper.getFinalHotel);
			preparedStatement.setString(1, hotelBook);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				hbmssearch.setHotel_id(resultSet.getString(1));
				hbmssearch.setCity(resultSet.getString(2));
				hbmssearch.setHotel_name(resultSet.getString(3));
				hbmssearch.setAddress(resultSet.getString(4));
				hbmssearch.setDescription(resultSet.getString(5));
				hbmssearch.setRate(resultSet.getDouble(6));
				hbmssearch.setMobileno(resultSet.getString(7));
				hbmssearch.setPhone(resultSet.getString(8));
				hbmssearch.setRating(resultSet.getString(9));
				hbmssearch.setEmail(resultSet.getString(10));
				hbmssearch.setFax(resultSet.getString(11));
				List.add(hbmssearch);
				hbmssearch=new HBMSHotel();
			}
		}
		catch(SQLException e){
			logger.error("Insertion failed SQL error ");
			throw new HBMSException(e.getMessage());
		}
		return List;
	}

	@Override
	public List<HBMSRoom> getRoomType(String hotelBook) throws HBMSException {
		List<HBMSRoom> List = new ArrayList<HBMSRoom>();
		HBMSRoom hbmsroom = new HBMSRoom();
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement=con.prepareStatement(QuerryMapper.View_HotelByRoomtype);
			preparedStatement.setString(1, hotelBook);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				hbmsroom.setRoomType(resultSet.getString(1));
				hbmsroom.setRoomId(resultSet.getString(2));
				List.add(hbmsroom);
				hbmsroom=new HBMSRoom();
			}
		}
		catch(SQLException e)
		{
			logger.error("Insertion failed SQL error ");
			throw new HBMSException(e.getMessage());
		}
		return List;
	}

	@Override
	public List<HBMSRoom> getRooms(String roomTypeSelected,String hotelBook)
			throws HBMSException {
		// TODO Auto-generated method stub
		List<HBMSRoom> List = new ArrayList<HBMSRoom>();
		HBMSRoom hbmsroom = new HBMSRoom();
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		try {
			preparedStatement=con.prepareStatement(QuerryMapper.View_RoomsByRoomId);
			preparedStatement.setString(1, hotelBook);
			preparedStatement.setString(2, roomTypeSelected);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				hbmsroom.setRoomNo(resultSet.getString(1));
				List.add(hbmsroom);
				hbmsroom=new HBMSRoom();
			}
		}
		catch(SQLException e)
		{
			throw new HBMSException(e.getMessage());
		}
		return List;
	}

	@Override
	public List<Booked> bookRoom(int noOfRoom, String hotelBook,
			String roomTypeSelected, String user_id,String dateFrom,String dateTo,int noOfAdults,int noOfChild) throws HBMSException {
		// TODO Auto-generated method stub
		List<Booked> List = new ArrayList<Booked>();
		
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		 final LocalDate firstDate = LocalDate.parse(dateFrom, formatter);
	     final LocalDate secondDate = LocalDate.parse(dateTo, formatter);
		 final long days=ChronoUnit.DAYS.between(firstDate, secondDate);

		for(int i=0;i<noOfRoom;i++)
		{
			Booked booked = new Booked();
		try {
			preparedStatement=con.prepareStatement(QuerryMapper.Get_username);
			preparedStatement.setString(1, user_id);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				booked.setCusName(resultSet.getString(1));
			}
			preparedStatement=con.prepareStatement(QuerryMapper.Get_hotelName);
			preparedStatement.setString(1, hotelBook);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
			booked.setHotelName(resultSet.getString(1));
			}
			preparedStatement=con.prepareStatement(QuerryMapper.Get_Room_Type);
			preparedStatement.setString(1, hotelBook);
			preparedStatement.setString(2, roomTypeSelected);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				booked.setRoomType(resultSet.getString(1));
				booked.setRoomNo(resultSet.getString(2));
				booked.setAmount(resultSet.getDouble(3)*days);
			}
			
			preparedStatement=con.prepareStatement(QuerryMapper.Book_Room);
			preparedStatement.setString(1, hotelBook);
			preparedStatement.setString(2, roomTypeSelected);
			preparedStatement.setString(3, booked.getRoomNo());
			preparedStatement.executeQuery();
			preparedStatement=con.prepareStatement(QuerryMapper.Insert_Booking);
			preparedStatement.setString(1, roomTypeSelected);
			preparedStatement.setString(2, user_id);
				preparedStatement.setString(3,dateFrom);
				preparedStatement.setString(4,dateTo);
				preparedStatement.setInt(5, noOfAdults);
				preparedStatement.setInt(6, noOfChild);
				preparedStatement.setDouble(7, booked.getAmount());
				preparedStatement.setString(8, booked.getRoomNo());
				preparedStatement.setString(9, hotelBook);
				preparedStatement.executeQuery();
				preparedStatement=con.prepareStatement(QuerryMapper.Get_BookingId);
				preparedStatement.setString(1, hotelBook);
				preparedStatement.setString(2, roomTypeSelected);
				preparedStatement.setString(3, booked.getRoomNo());
				resultSet=preparedStatement.executeQuery();
				while (resultSet.next()) {
					booked.setBookId(resultSet.getString(1));
				}
			List.add(booked);
			
		}
		
		catch(SQLException e)
		{
			logger.error("Insertion failed SQL error ");
			throw new HBMSException(e.getMessage());
		}
		
		}
		
		
		return List;
		
	}
	public List<HBMSBooking> getStatus(String user) throws HBMSException {
		// TODO Auto-generated method stub
		List<HBMSBooking> List = new ArrayList<HBMSBooking>();
		HBMSBooking hbmsbooking = new HBMSBooking();
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try {
			
			preparedStatement=con.prepareStatement(QuerryMapper.getBookingDetails);
			
			preparedStatement.setString(1, user);
			resultSet=preparedStatement.executeQuery();
			ResultSet resultSet1 = null;
			ResultSet resultSet2 = null;
			while(resultSet.next())
			{
				hbmsbooking.setBooking_id(resultSet.getString(1));
				hbmsbooking.setRoom_id(resultSet.getString(2));
				preparedStatement=con.prepareStatement(QuerryMapper.Get_username);
				preparedStatement.setString(1, resultSet.getString(3));
				resultSet1=preparedStatement.executeQuery();
				while (resultSet1.next()) {
					hbmsbooking.setUserName(resultSet1.getString(1));
				}
				hbmsbooking.setBooking_from(resultSet.getDate(4));
				hbmsbooking.setBooking_to(resultSet.getDate(5));
				hbmsbooking.setNo_of_audults(resultSet.getInt(6));
				hbmsbooking.setNo_of_children(resultSet.getInt(7));
				hbmsbooking.setAmount(resultSet.getDouble(8));
				hbmsbooking.setRoom_no(resultSet.getString(9));
				preparedStatement=con.prepareStatement(QuerryMapper.Get_hotelName);
				preparedStatement.setString(1, resultSet.getString(10));
				resultSet2=preparedStatement.executeQuery();
				while (resultSet2.next())
				{
					hbmsbooking.setHotel_name(resultSet2.getString(1));
				}
				List.add(hbmsbooking);
				hbmsbooking=new HBMSBooking();
			}
		}
			catch (SQLException e) {
				// TODO: handle exception
				throw new HBMSException(e.getMessage());
			}
		return List;
	}

	@Override
	public int getNoOfRooms(String hotelBook,
			String roomTypeSelected) throws HBMSException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		int roomsAvail=0;
		try{
			preparedStatement=con.prepareStatement(QuerryMapper.Get_Number_of_Rooms);
			preparedStatement.setString(1, hotelBook);
			preparedStatement.setString(2, roomTypeSelected);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				roomsAvail=Integer.parseInt(resultSet.getString(1));
			}
			
		}
		catch (SQLException e)
		{
			throw new HBMSException(e.getMessage());
		}
		return roomsAvail;
		
	}

	@Override
	public boolean validId(String id) throws HBMSException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		String user=null;
		try {
			preparedStatement=con.prepareStatement(QuerryMapper.isvalid);
			preparedStatement.setString(1, id);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				user=resultSet.getString(1);
			}
			if(user==null)
			{
				return true;
			}
			else
				return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new HBMSException(e.getMessage());
		}
		
	}
	@Override
	public List<HBMSBooking> viewById(String hotel_id) throws HBMSException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		List<HBMSBooking> List = new ArrayList<HBMSBooking>();
		HBMSBooking hbmsbooking = null;
		try {
			preparedStatement=con.prepareStatement(QuerryMapper.VIEW_BY_ID);
			preparedStatement.setString(1,hotel_id);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				hbmsbooking=new HBMSBooking();
				hbmsbooking.setBooking_id(resultSet.getString(1));
				hbmsbooking.setRoom_id(resultSet.getString(2));
				hbmsbooking.setUser_id(resultSet.getString(3));
				hbmsbooking.setBooking_from(resultSet.getDate(4));
				hbmsbooking.setBooking_to(resultSet.getDate(5));
				hbmsbooking.setNo_of_audults(resultSet.getInt(6));
				hbmsbooking.setNo_of_children(resultSet.getInt(7));
				hbmsbooking.setAmount(resultSet.getDouble(8));
				hbmsbooking.setRoom_no(resultSet.getString(9));
				
				List.add(hbmsbooking);
			}
		}
		catch(SQLException e)
		{
			throw new HBMSException(e.getMessage());
		}
		return List;
	}
	@Override
	public List<HBMSGuest> viewGuest(String hotel_id) throws HBMSException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		
		List<HBMSGuest> List = new ArrayList<HBMSGuest>();
		HBMSGuest hbmsguest = null;
		
		try {
			preparedStatement=con.prepareStatement(QuerryMapper.VIEW_Guest);
			preparedStatement.setString(1, hotel_id);
			resultSet=preparedStatement.executeQuery();
			/*preparedStatement=con.prepareStatement(QuerryMapper.VIEW_USER);
			preparedStatement.setString(1,user_id);*/
			/*resultSet1=preparedStatement.executeQuery();*/
			
			while(resultSet.next())
			{
				hbmsguest=new HBMSGuest();
				//hbmsguest.setBooking_id(resultSet.getString(1));
				hbmsguest.setRoom_id(resultSet.getString(1));
				
				preparedStatement=con.prepareStatement(QuerryMapper.VIEW_USER);
				preparedStatement.setString(1,resultSet.getString(2));
				resultSet1=preparedStatement.executeQuery();
				while(resultSet1.next())
				{
					hbmsguest.setUser_name(resultSet1.getString(1));
				}
				
				hbmsguest.setBooking_from(resultSet.getDate(3));
				hbmsguest.setBooking_to(resultSet.getDate(4));
				hbmsguest.setNo_of_audults(resultSet.getInt(5));
				hbmsguest.setNo_of_children(resultSet.getInt(6));
				//hbmsguest.setAmount(resultSet.getDouble(8));
				//hbmsguest.setHotel_id(resultSet.getString(9));
				hbmsguest.setRoom_no(resultSet.getString(7));
				List.add(hbmsguest);
			}
		}
		catch(SQLException e)
		{
			throw new HBMSException(e.getMessage());
		}
		return List;
	}

	@Override
	public List<HBMSBooking> viewByDate(String book_date)
			throws HBMSException {
		// TODO Auto-generated method stub
		List<HBMSBooking> List = new ArrayList<HBMSBooking>();
		HBMSBooking hbmsguest = new HBMSBooking();
		Connection con=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		ResultSet resultSet2 = null;
		ResultSet resultSet3 = null;
		try {
			preparedStatement=con.prepareStatement(QuerryMapper.VIEW_BY_DATE);
			preparedStatement.setString(1,book_date);
			preparedStatement.setString(2,book_date);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
			
				hbmsguest.setBooking_from(resultSet.getDate(1));
				hbmsguest.setBooking_to(resultSet.getDate(2));
				hbmsguest.setNo_of_audults(resultSet.getInt(3));
				hbmsguest.setNo_of_children(resultSet.getInt(4));
				hbmsguest.setRoom_no(resultSet.getString(5));
				preparedStatement=con.prepareStatement(QuerryMapper.VIEW_NAME);
				preparedStatement.setString(1,resultSet.getString(6));
				resultSet2=preparedStatement.executeQuery();
				while(resultSet2.next())
				{
					hbmsguest.setHotel_name(resultSet2.getString(1));
				}
				preparedStatement=con.prepareStatement(QuerryMapper.VIEW_USER);
				preparedStatement.setString(1,resultSet.getString(7));
				resultSet3=preparedStatement.executeQuery();
				while(resultSet3.next())
				{
					hbmsguest.setUserName(resultSet3.getString(1));
				}
				
				
				
				List.add(hbmsguest);
				hbmsguest=new HBMSBooking();
			}
		}
		catch(SQLException e)
		{
			throw new HBMSException(e.getMessage());
		}
		return List;
		
	}

}
