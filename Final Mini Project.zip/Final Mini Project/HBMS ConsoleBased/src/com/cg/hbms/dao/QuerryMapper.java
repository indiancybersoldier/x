package com.cg.hbms.dao;

public class QuerryMapper {
	public static final String Insert_Querry="Insert into USER_DETAILS(user_id,password,user_name,mobile_no,phone,address,email) VALUES(?,?,?,?,?,?,?)";
	public static final String Valid_Login="Select role from USER_DETAILS WHERE user_id=? and password=?";
	public static final String Insert_Hotel="Insert into hotel_details values(?,?,?,?,?,?,?,?,?,?,?)";
	public static final String VIEW_HOTELS = "select hotel_id,hotel_name,city from hotel_details";
	public static final String VIEW_BOOKINGS="select booking_id,room_id from booking_details WHERE booking_from=? AND booking_to=? REFERENCES room_details";
	public static final String Update_Des="Update hotel_details set description = ? where hotel_id = ?";
	public static final String Search_hotels="Select hotel_id,city,hotel_name,address,description,avg_rate_per_night,phone_no1,phone_no2,rating,email,fax from hotel_details where city=?";
	public static final String View_HotelByCity="Select city from hotel_details group by city";
	public static final String getFinalHotel="Select hotel_id,city,hotel_name,address,description,avg_rate_per_night,phone_no1,phone_no2,rating,email,fax from hotel_details where hotel_id=?";
	public static final String View_HotelByRoomtype = "SELECT ROOM_TYPE,room_id FROM ROOM_DETAILS where hotel_id=? GROUP BY ROOM_TYPE,room_id";
	public static final String View_RoomsByRoomId = "SELECT room_no FROM room_details WHERE hotel_id=? AND room_id=? AND availability='Y'";
	public static final String Get_username = "SELECT user_name from user_details where user_id=?";
	public static final String Get_hotelName = "SELECT hotel_name FROM hotel_details where hotel_id=?";
	//public static final String Get_Room_Type = "SELECT room_type FROM room_details where hotel_id=? and room_id=? GROUP BY room_type";
	public static final String Get_Room_Type = "SELECT room_type,room_no,per_night_rate FROM room_details where hotel_id=? and room_id=? AND availability='Y' GROUP BY room_type,ROOM_NO,PER_NIGHT_RATE";
	public static final String Book_Room = "Update room_details set availability = 'N' where hotel_id=? and room_id=? and room_no=?";
	public static final String Insert_Booking = "INSERT INTO booking_details values(concat('BK',to_char(sequence_booking.nextval, '000000')),?,?,to_date(?,'dd/MM/yyyy'),to_date(?,'dd/MM/yyyy'),?,?,?,?,?)";
	public static final String Get_BookingId = "SELECT BOOKING_ID FROM booking_details where hotel_id=? and room_id=? and room_no=?";
	public static final String getBookingDetails="select * from booking_details where user_id=?";
	public static final String Get_Number_of_Rooms ="SELECT COUNT(room_no) FROM room_details WHERE hotel_id=? and room_id=? AND availability='Y'";
	public static final String VIEW_BY_ID= "SELECT booking_id,room_id,user_id,booked_from,booked_to,no_of_adults,no_of_childrean,amount,room_no FROM booking_details WHERE hotel_id=?";

	public static final String VIEW_BY_DATE="select booked_from,booked_to,no_of_adults,no_of_childrean,room_no,hotel_id,user_id from booking_details where to_date(?,'DD/MM/YYYY')>=booked_from AND TO_DATE(?,'DD/MM/YYYY')<=BOOKED_TO";
    
	public static final String VIEW_NAME= "SELECT hotel_name FROM hotel_details WHERE hotel_id=?";
	public static String isvalid="SELECT user_id FROM user_details WHERE user_id=?";

	public static final String VIEW_Guest= "SELECT room_id,user_id,booked_from,booked_to,no_of_adults,no_of_childrean,room_no FROM booking_details WHERE hotel_id=?";
	
	public static final String VIEW_USER= "SELECT user_name FROM user_details WHERE user_id=?";
}




