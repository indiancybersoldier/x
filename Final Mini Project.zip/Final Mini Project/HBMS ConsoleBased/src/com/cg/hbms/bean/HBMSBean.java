package com.cg.hbms.bean;

public class HBMSBean {
String user_id;
String pass;
String user_name;
String mobileno;
String phone;
String address;
String email;
public HBMSBean(String user_id, String pass, String user_name, String mobileno,
		String phone, String address, String email) {
	super();
	this.user_id = user_id;
	this.pass = pass;
	this.user_name = user_name;
	this.mobileno = mobileno;
	this.phone = phone;
	this.address = address;
	this.email = email;
}
public HBMSBean()
{
	
}
public String getUser_id() {
	return user_id;
}
public void setUser_id(String user_id) {
	this.user_id = user_id;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}
public String getUser_name() {
	return user_name;
}
public void setUser_name(String user_name) {
	this.user_name = user_name;
}
public String getMobileno() {
	return mobileno;
}
public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
}
