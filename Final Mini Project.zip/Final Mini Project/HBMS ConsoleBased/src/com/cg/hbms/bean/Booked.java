package com.cg.hbms.bean;

public class Booked {

	private String hotelName;
	private String cusName;
	private String roomType;
	private double amount;
	private String bookId;
	private String roomNo;
	public Booked(String hotelName, String cusName, String roomType, double amount, String bookId, String roomNo) {
		super();
		this.hotelName = hotelName;
		this.cusName = cusName;
		this.roomType = roomType;
		this.amount = amount;
		this.bookId = bookId;
		this.roomNo = roomNo;
	}
	public Booked()
	{
		
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getBookId() {
		return bookId;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	public String getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
}
