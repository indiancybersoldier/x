package com.cg.hbms.bean;

import java.sql.Date;

public class HBMSBooking {
	
	private String booking_id;
	private String room_id ;
	private String user_id;
	private Date booking_from;
	private Date booking_to;
	private int no_of_audults;
	private int no_of_children;
	private double amount;
	private String userName;
	private String room_no;
	private String hotel_name;
	
	
	public HBMSBooking(String booking_id, String room_id, String user_id,
			Date booking_from, Date booking_to, int no_of_audults,
			int no_of_children, double amount,String userName,String room_no,String hotel_name) {
		super();
		this.booking_id = booking_id;
		this.room_id = room_id;
		this.user_id = user_id;
		this.booking_from = booking_from;
		this.booking_to = booking_to;
		this.no_of_audults = no_of_audults;
		this.no_of_children = no_of_children;
		this.amount = amount;
		this.userName=userName;
		this.room_no=room_no;
		this.hotel_name=hotel_name;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public HBMSBooking() {
		// TODO Auto-generated constructor stub
	}
	public String getBooking_id() {
		return booking_id;
	}
	public void setBooking_id(String booking_id) {
		this.booking_id = booking_id;
	}
	public String getRoom_id() {
		return room_id;
	}
	public void setRoom_id(String room_id) {
		this.room_id = room_id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public Date getBooking_from() {
		return booking_from;
	}
	public void setBooking_from(Date booking_from) {
		this.booking_from = booking_from;
	}
	public Date getBooking_to() {
		return booking_to;
	}
	public void setBooking_to(Date booking_to) {
		this.booking_to = booking_to;
	}
	public int getNo_of_audults() {
		return no_of_audults;
	}
	public void setNo_of_audults(int no_of_audults) {
		this.no_of_audults = no_of_audults;
	}
	public int getNo_of_children() {
		return no_of_children;
	}
	public void setNo_of_children(int no_of_children) {
		this.no_of_children = no_of_children;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getRoom_no() {
		return room_no;
	}
	public void setRoom_no(String room_no) {
		this.room_no = room_no;
	}
	
	
	public String getHotel_name() {
		return hotel_name;
	}
	public void setHotel_name(String hotel_name) {
		this.hotel_name = hotel_name;
	}

}
