package com.cg.hbms.bean;

public class HBMSRoom {
private String hotelId;
private String roomId;
private String roomNo;
private String roomType;
private Double rate;
private char avail;
public HBMSRoom(String hotelId, String roomId, String roomNo, String roomType,
		Double rate, char avail) {
	super();
	this.hotelId = hotelId;
	this.roomId = roomId;
	this.roomNo = roomNo;
	this.roomType = roomType;
	this.rate = rate;
	this.avail = avail;
}
public HBMSRoom(){
	
}
public String getHotelId() {
	return hotelId;
}
public void setHotelId(String hotelId) {
	this.hotelId = hotelId;
}
public String getRoomId() {
	return roomId;
}
public void setRoomId(String roomId) {
	this.roomId = roomId;
}
public String getRoomNo() {
	return roomNo;
}
public void setRoomNo(String roomNo) {
	this.roomNo = roomNo;
}
public String getRoomType() {
	return roomType;
}
public void setRoomType(String roomType) {
	this.roomType = roomType;
}
public Double getRate() {
	return rate;
}
public void setRate(Double rate) {
	this.rate = rate;
}
public char getAvail() {
	return avail;
}
public void setAvail(char avail) {
	this.avail = avail;
}
}
