package com.cg.hbms.presentation;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hbms.bean.Booked;
import com.cg.hbms.bean.HBMSBean;
import com.cg.hbms.bean.HBMSBooking;
import com.cg.hbms.bean.HBMSGuest;
import com.cg.hbms.bean.HBMSHotel;
import com.cg.hbms.bean.HBMSRoom;
import com.cg.hbms.exception.HBMSException;
import com.cg.hbms.service.HBMSService;
import com.cg.hbms.service.HBMSServiceImpl;

public class Hbmscontroller {
	
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws HBMSException{
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("resources//log4j.properties");
		HBMSBean hbmsbean=null;
		HBMSService hbmsservice=null;
		int valid=0;
		while(true)
		{
			System.out.println("Welcome to Hotel Marriot");
			System.out.println("------------------------");
			System.out.println("1.Register");
			System.out.println("2.Login");
			System.out.println("3.To Exit");
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter your Opinion");
			int opinion=scan.nextInt();
			scan.nextLine();
			switch (opinion) {
			case 1: hbmsbean=new HBMSBean();
			hbmsservice= new HBMSServiceImpl();
					System.out.println("Enter the User Id");
					while(valid==0)
					{
						String id=scan.nextLine();
						if(id.length()==4 )	
						{
							if(hbmsservice.validId(id))
							{
								hbmsbean.setUser_id(id);
								valid=1;
							}
							else
							{
								System.out.println("This User id is already Taken");
							}
						}
						else
						{
							System.out.println("The length of ID should be exactly 4");
						}
						
					}
					System.out.println("Enter the password to be kept");
					hbmsbean.setPass(scan.nextLine());
					System.out.println("Enter the User Name");
					
					while(valid==0)
					{
						String username=scan.nextLine();
						if(username.matches("^[A-Z][A-Za-z ]{3,20}"))	
						{
					hbmsbean.setUser_name(username);
						valid=1;
						}
						else
						{
							System.out.println("Please follow this instruction : \n Name should start with Uppercase \n Max length can be 20");
						}
						
					}
					System.out.println("Enter the Mobile Number");
					hbmsbean.setMobileno(scan.nextLine());
					System.out.println("Enter the Phone Number");
					hbmsbean.setPhone(scan.nextLine());
					System.out.println("Enter the Address");
					hbmsbean.setAddress(scan.nextLine());
					System.out.println("Enter the Email Address");
					hbmsbean.setEmail(scan.nextLine());
					try{
					hbmsservice.registerCustomer(hbmsbean);
					System.out.println("You have Successfully registered \n Thank you !!");
					System.out.println("Enter 1 to Go Back to Main Menu");
					System.out.println("Enter 2 to exit");
					int option=scan.nextInt();
					scan.nextLine();
					if(option==2)
					{
						System.out.println("Thank You !!");
					 	System.exit(0);
					}
					}
					catch (HBMSException e) {
						logger.error("exception occured", e);
						// TODO: handle exception
						//System.out.println(e.getMessage());
					}
				break;
			case 2:
				hbmsbean=new HBMSBean();
				hbmsservice=new HBMSServiceImpl();
				System.out.println("Enter the User Id");
				hbmsbean.setUser_id(scan.nextLine());
				System.out.println("Enter the Password");
				hbmsbean.setPass(scan.nextLine());
				try{
					String role=(String)hbmsservice.login(hbmsbean);
					if(role.equals("customer"))
					{
						System.out.println("Hii Customer");
						int stop=1;
						while(true && stop==1){
							System.out.println("Please Enter the work you want to do");
							System.out.println("------------------------------------");
							System.out.println("Press 1 For Searching Hotel or Booking Hotel Rooms");
							System.out.println("Press 2 For Checking the Status of Your Booking");
							System.out.println("Press 9 to Log Out");
							System.out.println("Press 0 to exit");
							int custOption=scan.nextInt();
							scan.nextLine();
							switch (custOption) {
							case 1:
								System.out.println("Welcome to Hotel Searching and Booking Menu");
							 	System.out.println("-------------------------------------------");
							 	
							 
										hbmsservice=new HBMSServiceImpl();
										try{
											List<HBMSHotel> list = hbmsservice.getAllHotelCity();
											
											if(list==null){
												System.out.println("No Hotels");
											}
											
											System.out.println("Option\tHotel City");
											System.out.println("------\t----------");
											int k=0;
											String hotelLoc[]=new String[1000];
											 for(HBMSHotel hlist : list) {
												 	k++;
												 	hotelLoc[k]=hlist.getCity();
										            System.out.println(k+" \t"+hotelLoc[k]);
										        }
											 System.out.println("Select the Location for which you want to look hotel for");
											 int searchSelect=scan.nextInt();
											 scan.nextLine();
											 String search=hotelLoc[searchSelect];
											 try{
												 List<HBMSHotel> hbmsHotels=hbmsservice.searchHotel(search);
												 if(hbmsHotels==null){
														System.out.println("No hotel for this location");
													}
													System.out.println("Option\t\tHotel Name\t\tAverage Rate\t\tDescription\t\t+Rating");
													System.out.println("--------\t----------\t\t------------\t\t-----------\t\t-------");
													int h=0;
													String[] selectHotel=new String[1000];
													 for(HBMSHotel hlist : hbmsHotels) {
														 h++;
														 selectHotel[h]=hlist.getHotel_id();
												            System.out.println(h+" \t\t"+hlist.getHotel_name()+"  \t\t"+hlist.getRate()+" \t\t\t"+hlist.getDescription()+" \t\t"+hlist.getRating());
												        }
													 System.out.println("Select the hotel you want to book");
													 int optionBook=scan.nextInt();
													 scan.nextLine();
													 String hotelBook=selectHotel[optionBook];
													 try{
														 System.out.println("Hotel Name\t\tCity\t\t\tAddress\t\t\tDescription\tAverage Rate Per Night\t\tMobile Number\t\tTelephone Number\tRating\t\tEmail Address\t\tFax Number");
														 System.out.println("----------\t\t-------\t\t\t-------\t\t\t-----------\t-------------------------\t---------------\t\t-------------\t\t--------\t--------------\t\t--------------");
														 List<HBMSHotel> hotel=hbmsservice.searchHotelById(hotelBook);
														 for(HBMSHotel hlist : hotel) {
													            System.out.println(hlist.getHotel_name()+"  \t\t"+hlist.getCity()+"  \t\t"+hlist.getAddress()+"  \t\t"+hlist.getDescription()+"  \t\t"+hlist.getRate()+" \t\t\t"+hlist.getMobileno()+"  \t\t"+hlist.getPhone()+" \t\t"+hlist.getRating()+"  \t\t"+hlist.getEmail()+"  \t"+hlist.getFax());
													        }
														System.out
																.println("\n\nPlease Choose the Room Type You want");
														List<HBMSRoom> roomType=hbmsservice.getRoomType(hotelBook);
														System.out.println("Option\t\tRoom Type");
														System.out.println("--------\t----------");
														int roomTypeOption=0;
														String[] selectRoomType=new String[10];
														 for(HBMSRoom rlist : roomType) {
															 roomTypeOption++;
															 selectRoomType[roomTypeOption]=rlist.getRoomId();
													            System.out.println(roomTypeOption+"  \t\t"+rlist.getRoomType());
													        }
														 System.out.println("Select the Room Type you want to book");
														 int optionRoom=scan.nextInt();
														 String roomTypeSelected=selectRoomType[optionRoom];
														 List<HBMSRoom>rooms=hbmsservice.getRooms(roomTypeSelected,hotelBook);
														/* int roomNumber=0;
														 String[] selectedRoom=new String[20];
														 for(HBMSRoom rno : rooms) {
															 roomNumber++;
															 selectedRoom[roomNumber]=rno.getRoomNo();
													            System.out.println(roomNumber+"  \t\t"+rno.getRoomNo());
													        }*/
														 int roomsAvail=hbmsservice.getNoOfRooms(hotelBook,roomTypeSelected);
														 System.out
																.println("We have "+roomsAvail+" rooms Available as your search");
														 System.out
																.println("Enter the Number of Rooms you want to book");
														 int noOfRoom=scan.nextInt();
														 scan.nextLine();
														 while(!(noOfRoom<=roomsAvail))
														 {
															 System.out
																	.println("Enter the Correct Input");
															 System.out
																	.println("You can maximum Book "+roomsAvail+" rooms");
															 noOfRoom=scan.nextInt();
															 scan.nextLine();
														 }
														 System.out
																.println("Room Booking Form");
														 System.out
																.println("-----------------");
														 System.out
																.println("Enter the Date from which you need to Book the room");
														 
														 String dateFrom=scan.nextLine();
														 System.out
																.println("Enter the Date upto which you want the room to be Booked");
														
														 String dateTo=scan.nextLine();
													
														 System.out
																.println("Enter the number of Adults");
														 int noOfAdults=scan.nextInt();
														 scan.nextLine();
														 System.out
																.println("Enter the number of Children");
														 int noOfChild=scan.nextInt();
														 scan.nextLine();
														try{
														 List<Booked>booked=hbmsservice.bookRoom(noOfRoom,hotelBook,roomTypeSelected,hbmsbean.getUser_id(),dateFrom,dateTo,noOfAdults,noOfChild);
														 System.out
																.println("\tThank Youn for Booking with us\n\n");
														 System.out
																.println("\tYour Booking Deatails :\n\n");
														 System.out.println("Booking ID\t\tCustomer Name\t\tHotel Name\t\tRoom Type\t\tRoom Number\t\tAmount Paid");
															System.out.println("--------\t\t----------\t\t----------\t\t----------\t\t----------\t----------");
															 for(Booked blist : booked) {
														            System.out.println(blist.getBookId()+" \t\t"+blist.getCusName()+"  \t\t"+blist.getHotelName()+"  \t\t"+blist.getRoomType()+"  \t\t"+blist.getRoomNo()+"  \t\t"+blist.getAmount());
														        }
														}
														catch(HBMSException e)
														{
															logger.error("exception occured", e);
															throw new HBMSException(e.getMessage());
														}
													 }
													 catch(HBMSException e)
													 {
														 logger.error("exception occured", e);
														 throw new HBMSException(e.getMessage());
													 }
											 }
											 catch(HBMSException e)
											 {
												 logger.error("exception occured", e);
												 throw new HBMSException(e.getMessage());
											 }
											
											
										}
										catch(HBMSException e)
										{
											logger.error("exception occured", e);
											throw new HBMSException(e.getMessage());
										}
										break;
									
									
							 	
							 	
							
							case 2:
								System.out.println("Welcome to Check Your Booking Details");
								System.out.println("------------------------------------");
								String user=hbmsbean.getUser_id();
								List<HBMSBooking> book=hbmsservice.getStatus(user);
								if(book==null){
									System.out.println("list is null");
								}
								System.out.println("Hotel Name\t\tBooking ID\t\tCustomer Name\t\tRoom ID\t\tBooked From\tBooked To\tNo of Adults\tNo. of Children\t\tAmount\t\tRoom Number");
								System.out.println("------------\t\t--------\t\t------------\t\t----------\t---------\t-------\t\t-----------\t---------\t\t------\t\t----------");
								 for(HBMSBooking booking : book) {
							            System.out.println(booking.getHotel_name()+"\t\t"+booking.getBooking_id()+" \t\t"+booking.getUserName()+" \t\t"+booking.getRoom_id()+" \t\t"+booking.getBooking_from()+" \t"+booking.getBooking_to()+" \t"+booking.getNo_of_audults() +"\t\t"+booking.getNo_of_children()+"\t\t\t"+booking.getAmount()+"\t\t"+booking.getRoom_no());
							        }
								break;
							case 9:System.out.println("Logging Out ..."); 
								stop=0;
								break;
							case 0:
								System.out.println("Thank You for Visiting");
								System.exit(0);
							default:
								System.out.println("Enter the Correct Option Please");
								break;
							}
							
						}
					}
					else if(role.equals("admin"))
					{
						System.out.println("Hii Admin");
						int stop=1;
						while(true && stop==1){
						System.out.println("Please Enter the work you want to do");
						System.out.println("------------------------------------");
						System.out.println("1.Add Hotel");
						System.out.println("2.Update Hotel");
						System.out.println("3.Delete Hotel");
						System.out.println("4.View Reports");
						System.out.println("5.To Logout");
						System.out.println("6.To exit from Hotel Booking System");
						int adminOption=scan.nextInt();
						scan.nextLine();
						switch (adminOption) {
						case 1:
								System.out.println("Enter the Details of new Hotel :");
								System.out.println("--------------------------------");
								HBMSHotel hbmshotel=new HBMSHotel();
								hbmsservice=new HBMSServiceImpl();
							 	System.out.println("Add Hotel :");
							 	System.out.println("-----------");
							 	System.out.println("Enter the Hotel ID");
							 	hbmshotel.setHotel_id(scan.nextLine());
							 	System.out.println("Enter the City of hotel");
							 	hbmshotel.setCity(scan.nextLine());
							 	System.out.println("Enter the Hotel Name");
							 	hbmshotel.setHotel_name(scan.nextLine());
							 	System.out.println("Enter the Address of Hotel");
							 	hbmshotel.setAddress(scan.nextLine());
							 	System.out.println("Enter the Description of the hotel");
							 	hbmshotel.setDescription(scan.nextLine());
							 	System.out.println("Enter the Avg Rate Per Night");
							 	hbmshotel.setRate(scan.nextDouble());
							 	scan.nextLine();
							 	System.out.println("Enter the Mobile Number of Hotel");
							 	hbmshotel.setMobileno(scan.nextLine());
							 	System.out.println("Enter the Telephone Numeber of Hotel");
							 	hbmshotel.setPhone(scan.nextLine());
							 	System.out.println("Enter the Rating of Hotel");
							 	hbmshotel.setRating(scan.nextLine());
							 	System.out.println("Enter the Email Address of the Hotel");
							 	hbmshotel.setEmail(scan.nextLine());
							 	System.out.println("Enter the Fax Number");
							 	hbmshotel.setFax(scan.nextLine());
							 	try{
							 		hbmsservice.addHotel(hbmshotel);
							 		System.out.println("Hotel Added Successfully");
							 	}
							 	catch (HBMSException e) {
									// TODO: handle exception
							 		logger.error("exception occured", e);
							 		throw new HBMSException(e.getMessage());
								}
							break;
						case 2:
							System.out.println("Welcome to Hotel Updation Menu");
							System.out.println("--------------------------------");
							int stop1=1;
							while(true && stop1==1){
							System.out.println("Press 1 to Update Decription of Hotel Includeing any Special Offers of a Specific Hotel");
							System.out.println("Press 2 to Update Rooms' Information of a specific Hotel");
							int updateOption=scan.nextInt();
							scan.nextLine();
							hbmsservice=new HBMSServiceImpl();
							hbmshotel=new HBMSHotel();
							switch (updateOption) {
							case 1:
									System.out.println("Welcome to Hotel Description Updation Menu");
									System.out.println("------------------------------------------");
									int stop2=1;
									while(true && stop2==1){
										System.out.println("Press 1 For Adding Or Modifying Description Details of a specific Table");
										System.out.println("Press 2 For deleting Description Details of a specific Table");
										System.out.println("Press 3 For Going Back to Previous Menu");
										int updateDes=scan.nextInt();
										scan.nextLine();
										switch (updateDes) {
										case 1:
											System.out.println("Enter the Hotel Id whose Description Needs to be Added or Modified");
										 	String hotelid=scan.nextLine();
										 	System.out.println("Enter the Value you want to insert");
										 	String des=scan.nextLine();
										 	try{
										 		hbmsservice.updatedes(hotelid,des);
										 		System.out.println("Decription Added or Modified Successfully");
										 	}
										 	catch (HBMSException e) {
												// TODO: handle exception
										 		logger.error("exception occured", e);
										 		throw new HBMSException(e.getMessage());
										 	}
											break;
										case 2:
											System.out.println("Enter the Hotel Id whose description needs to be deleted");
											hotelid=scan.nextLine();
											des="";
											try{
												hbmsservice.updatedes(hotelid, des);
												System.out.println("Description Deleted Successfully");
											}
											catch (HBMSException e) {
												// TODO: handle exception
												logger.error("exception occured", e);
												throw new HBMSException(e.getMessage());
											}
											break;
										case 3:
											System.out.println("Going back to previous menu");
											stop2=0;
											break;
										default:
											break;
										}
									}
								 	
								 	
								break;
							case 3:
								System.out.println("Going back to previous menu");
								stop1=0;
								break;
							default:
							}
							}
							break;
						
						
						case 4:		
								System.out.println("Welcome to the Menu of Viewing Reports");
								int stop_rep=1;
								while(true && stop_rep==1)
								{
								System.out.println("Select 1 for View List of Hotels");
								System.out.println("Select 2 to View Bookings of Specific Hotel");
								System.out.println("Select 3 to View guest list of specific hotel ");
								System.out.println("Select 4 to View bookings for specified date");
								System.out.println("Select 9 to go Back to Previous Menu");
								System.out.println("Select 0 to exit");
								int reportOption=scan.nextInt();
								scan.nextLine();
						switch (reportOption) {
						case 1:
							hbmsservice=new HBMSServiceImpl();
							try{
								List<HBMSHotel> list = hbmsservice.getAllHotelDetails();
								
								if(list==null){
									System.out.println("list is null");
								}
								System.out.println("Hotel ID\tHotel Name\t\tHotel City");
								System.out.println("--------\t----------\t\t----------");
								 for(HBMSHotel hlist : list) {
							            System.out.println(hlist.getHotel_id()+" \t\t"+hlist.getHotel_name()+"  \t\t"+hlist.getCity());
							        }

								
								
							}
							catch(HBMSException e)
							{
								throw new HBMSException(e.getMessage());
							}
							break;
						case 2:
							/*hbmsservice=new HBMSServiceImpl();
							System.out.println("Enter hotel id:");
							hotel_id=sc.next();*/
							try{
								List<HBMSHotel> list = hbmsservice.getAllHotelDetails();
								
								if(list==null){
									System.out.println("list is null");
								}
								System.out.println("Option \t\tHotel Name\t\tHotel City");
								System.out.println("--------\t----------\t\t----------");
								int op=0;
								String[] selectHotel=new String[1000];
								 for(HBMSHotel hlist : list) {
									 op++;
									 selectHotel[op]=hlist.getHotel_id();
							            System.out.println((op)+" \t\t"+hlist.getHotel_name()+"  \t\t"+hlist.getCity());
							        }
								 System.out.println("Enter the Option Whose Booking details are needed");
								 int opt=scan.nextInt();
								 String hotelBook=selectHotel[opt];
									
									List<HBMSBooking> blist = hbmsservice.viewById(hotelBook);
									if(blist.isEmpty()){
										System.out.println("NO Booking for this Hotel\n");
									}
									else{
									System.out.println("Booking Id\tRoom Id\tUser Id\tBooking From\tBooking To\tNo Of Adults\tNo Of Children\tAmount\tRoom No");
									System.out.println("-----------\t-------\t-------\t------------\t----------\t------------\t--------------\t------\t--------------");
									 for(HBMSBooking hlist : blist) {
								            System.out.println(hlist.getBooking_id()+" \t"+hlist.getRoom_id()+" \t"+hlist.getUser_id()+" \t"+hlist.getBooking_from()+" \t"+hlist.getBooking_to()+" \t"+hlist.getNo_of_audults()+" \t\t"+hlist.getNo_of_children()+" \t\t"+hlist.getAmount()+" \t\t"+hlist.getRoom_no());
								        }
									}
									 break;
								
							}
							catch(HBMSException e)
							{
								throw new HBMSException(e.getMessage());
							}
							 
							
						case 3:
							try{
								List<HBMSHotel> list = hbmsservice.getAllHotelDetails();
								
								if(list==null){
									System.out.println("list is null");
								}
								System.out.println("Option\t\tHotel Name\t\tHotel City");
								System.out.println("--------\t----------\t\t----------");
								int op=0;
								String[] selectguest=new String[1000];
								 for(HBMSHotel hlist : list) {
									 op++;
									 selectguest[op]=hlist.getHotel_id();
							            System.out.println((op)+" \t\t"+hlist.getHotel_name()+"  \t\t"+hlist.getCity());
							        }
								 System.out.println("Enter the Option Whose GuestList are to be needed");
								 int opt=scan.nextInt();
								 String hotelBook=selectguest[opt];
							
							
						
							
							List<HBMSGuest> listGuest = hbmsservice.viewGuest(hotelBook);
							
							if(listGuest.isEmpty()){
								System.out.println("No Guestlist  for this Hotel");
							}
							System.out.println("Room Id\tUser Name\t\tBooking From\tBooking To\tNo Of Adults\tNo Of Children\tRoom No");
							System.out.println("-------------------------------------------------------------------------------------------------------");
							 for(HBMSGuest glist : listGuest) {
						            System.out.println(glist.getRoom_id()+"\t"+glist.getUser_name()+" \t\t"+glist.getBooking_from()+" \t"+glist.getBooking_to()+" \t"+glist.getNo_of_audults()+" \t\t"+glist.getNo_of_children()+" \t\t"+glist.getRoom_no());
						            	
						            
						        }
							 break;
							}
							catch(HBMSException e)
							{
								throw new HBMSException(e.getMessage());
							}
						
						case 4:
							hbmsservice=new HBMSServiceImpl();
							String book_startdate=null;
							//String book_endDate=null;
							System.out.println("Enter specified date int the format[dd/mmm/yyyy]: to view bookings:");
							book_startdate=scan.nextLine();
							//System.out.println("Enter End date:");
							//book_endDate=sc.next();
							List<HBMSBooking> datelist = hbmsservice.viewByDate(book_startdate);

							if(datelist.isEmpty()){
								System.out.println("No Guestlist  for this Hotel on this date");
							}
							System.out.println("Hotel Name\tUser Name\tRoom no\tNo Of Adults\tNo Of Children\tBooking From\tBooking to");
							System.out.println("------------------------------------------------------------------------------------------------");
							 for(HBMSBooking glist : datelist) {
						            System.out.println(glist.getHotel_name()+" \t"+glist.getUserName()+" \t\t"+glist.getRoom_no()+" \t\t"+glist.getNo_of_audults()+" \t\t"+glist.getNo_of_children()+" \t"+glist.getBooking_from()+" \t"+glist.getBooking_to());
						            	
						            
						        }
							 break;
						case 9:
							stop_rep=0;
							System.out.println("Going Back to Previous Menu");
							break;
						case 0:
							System.out.println("Have a Nice Day !! GoOd Bye !!");
							System.exit(0);
						default: System.out.println("Enter the Correct Option");
							break;
						}
								}
								break;
						case 5:
							System.out.println("Going back to home menu");
							stop=0;
							break;
						case 6:
							System.out.println("Good Bye !! Visit Again");
							System.exit(0);
						default:
							break;
						}
						}
					}
					else
					{
						System.out.println("Sorry !! Invalid Login");
					}
				}
				catch (HBMSException e) {
					// TODO: handle exception
					logger.error("exception occured", e);
					//System.out.println(e.getMessage());
				}
				break;
			case 3:
				System.out.println("Have a nice day !!\nGood Bye !!");
				System.exit(0);
			default:System.out.println("Enter the Correct Input Please !!");
				break;
			}
			{
			
			}
	}
	}
}
