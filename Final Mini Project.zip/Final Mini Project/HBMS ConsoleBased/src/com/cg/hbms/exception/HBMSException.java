package com.cg.hbms.exception;

public class HBMSException extends Exception {
public HBMSException(String message)
{
	super(message);
}
}
