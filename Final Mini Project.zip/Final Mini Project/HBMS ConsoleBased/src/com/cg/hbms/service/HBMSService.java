package com.cg.hbms.service;

import java.util.List;

import com.cg.hbms.bean.Booked;
import com.cg.hbms.bean.HBMSBean;
import com.cg.hbms.bean.HBMSBooking;
import com.cg.hbms.bean.HBMSGuest;
import com.cg.hbms.bean.HBMSHotel;
import com.cg.hbms.bean.HBMSRoom;
import com.cg.hbms.exception.HBMSException;

public interface HBMSService {

	void registerCustomer(HBMSBean hbmsbean) throws HBMSException;

	String login(HBMSBean hbmsbean)throws HBMSException;

	void addHotel(HBMSHotel hbmshotel) throws HBMSException;

	public List<HBMSHotel> getAllHotelDetails()throws HBMSException;
	
	public List<HBMSBooking> getHotelDetails() throws HBMSException;
	
	public List<HBMSBooking> getBookingDetails() throws HBMSException;
	
	void updatedes(String hotelid, String des) throws HBMSException;

	public List<HBMSHotel> searchHotel(String search) throws HBMSException;

	public List<HBMSHotel> getAllHotelCity() throws HBMSException;

	public List<HBMSHotel> searchHotelById(String hotelBook) throws HBMSException;

	public List<HBMSRoom> getRoomType(String hotelBook) throws HBMSException;

	public List<HBMSRoom> getRooms(String roomTypeSelected,String hotelBook) throws HBMSException;

	public List<Booked> bookRoom(int noOfRoom, String hotelBook,
			String roomTypeSelected, String user_id,String dateFrom,String dateTo,int noOfAdults,int noOfChild) throws HBMSException;

	public List<HBMSBooking> getStatus(String user) throws HBMSException;

	public int getNoOfRooms(String hotelBook,String roomTypeSelected) throws HBMSException;

	public boolean validId(String id) throws HBMSException;

	public List<HBMSBooking> viewById(String hotel_id) throws HBMSException;

	public List<HBMSGuest> viewGuest(String hotelBook) throws HBMSException;

	public List<HBMSBooking> viewByDate(String book_startdate) throws HBMSException;
	
}
