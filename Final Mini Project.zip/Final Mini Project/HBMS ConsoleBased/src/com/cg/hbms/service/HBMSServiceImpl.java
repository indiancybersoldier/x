package com.cg.hbms.service;

import java.util.List;

import com.cg.hbms.bean.Booked;
import com.cg.hbms.bean.HBMSBean;
import com.cg.hbms.bean.HBMSBooking;
import com.cg.hbms.bean.HBMSGuest;
import com.cg.hbms.bean.HBMSHotel;
import com.cg.hbms.bean.HBMSRoom;
import com.cg.hbms.dao.HBMSDAO;
import com.cg.hbms.dao.HBMSDAOImpl;
import com.cg.hbms.exception.HBMSException;

public class HBMSServiceImpl implements HBMSService{
	HBMSDAO hbmsdao;
	@Override
	public void registerCustomer(HBMSBean hbmsbean) throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		hbmsdao.registerCustomer(hbmsbean);
	}
	@Override
	public String login(HBMSBean hbmsbean) throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		String role=hbmsdao.login(hbmsbean);
		return role;
	}
	@Override
	public void addHotel(HBMSHotel hbmshotel) throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		hbmsdao.addHotel(hbmshotel);
	}
	@Override
	public List<HBMSHotel> getAllHotelDetails() throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		
		List<HBMSHotel> List = hbmsdao.getAllHotelDetails();
		return List;
	}
	@Override
	public List<HBMSBooking> getHotelDetails() throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		
		List<HBMSBooking> List = hbmsdao.getHotelDetails();
		return List;
	}
	@Override
	public List<HBMSBooking> getBookingDetails() throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		List<HBMSBooking> List = hbmsdao.getBookingDetails();
		return List;
	}
	@Override
	public void updatedes(String hotelid, String des) throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		hbmsdao.updatedes(hotelid,des);
	}
	@Override
	public List<HBMSHotel> searchHotel(String search) throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		List<HBMSHotel>list=hbmsdao.searchHotel(search);
		return list;
	}
	@Override
	public List<HBMSHotel> getAllHotelCity() throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		List<HBMSHotel>list=hbmsdao.getAllHotelCity();
		return list;
	}
	@Override
	public List<HBMSHotel> searchHotelById(String hotelBook)
			throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		List<HBMSHotel>list=hbmsdao.searchHotelById(hotelBook);
		return list;
	}
	@Override
	public List<HBMSRoom> getRoomType(String hotelBook) throws HBMSException{
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		List<HBMSRoom>list=hbmsdao.getRoomType(hotelBook);
		return list;
	}
	@Override
	public List<HBMSRoom> getRooms(String roomTypeSelected,String hotelBook)
			throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		List<HBMSRoom>list=hbmsdao.getRooms(roomTypeSelected,hotelBook);
		return list;
	}
	@Override
	public List<Booked> bookRoom(int noOfRoom, String hotelBook,
			String roomTypeSelected, String user_id,String dateFrom,String dateTo,int noOfAdults,int noOfChild) throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		List<Booked> list=hbmsdao.bookRoom(noOfRoom,hotelBook,roomTypeSelected,user_id,dateFrom,dateTo,noOfAdults,noOfChild);
		return list;
	}
	@Override
	public List<HBMSBooking> getStatus(String user) throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		List<HBMSBooking>list=hbmsdao.getStatus(user);
		return list;
	}
	@Override
	public int getNoOfRooms(String hotelBook, String roomTypeSelected) throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		int roomsAvail=hbmsdao.getNoOfRooms(hotelBook,roomTypeSelected);
		return roomsAvail;
	}
	@Override
	public boolean validId(String id) throws HBMSException {
		hbmsdao=new HBMSDAOImpl();
		return hbmsdao.validId(id);
	}
	@Override
	public List<HBMSBooking> viewById(String hotel_id) throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		List<HBMSBooking>list=hbmsdao.viewById(hotel_id);
		return list;
		
	}
	@Override
	public List<HBMSGuest> viewGuest(String hotel_id) throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		List<HBMSGuest>list=hbmsdao.viewGuest(hotel_id);
		return list;
	}
	@Override
	public List<HBMSBooking> viewByDate(String book_date)
			throws HBMSException {
		// TODO Auto-generated method stub
		hbmsdao=new HBMSDAOImpl();
		List<HBMSBooking>list=hbmsdao.viewByDate(book_date);
		return list;
	}
	
}
