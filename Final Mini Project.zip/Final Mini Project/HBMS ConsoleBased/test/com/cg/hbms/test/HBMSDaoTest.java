package com.cg.hbms.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.Assert;

import com.cg.hbms.bean.Booked;
import com.cg.hbms.bean.HBMSBean;
import com.cg.hbms.bean.HBMSBooking;
import com.cg.hbms.bean.HBMSHotel;
import com.cg.hbms.bean.HBMSRoom;
import com.cg.hbms.dao.HBMSDAOImpl;
import com.cg.hbms.exception.HBMSException;

public class HBMSDaoTest {

	static HBMSDAOImpl dao;
	static Booked booked;
	static HBMSBean bean;
	static HBMSBooking booking;
	static HBMSHotel hbmsHotel;
	static HBMSRoom hbmsroom;
	

	@BeforeClass
	public static void initialize() {
		System.out.println("");
		dao = new HBMSDAOImpl();
		bean = new HBMSBean();
	}

	/*@Test
	public void testAddDonarDetails() throws HBMSException {

		assertNotNull(dao.addHotel(hbmsHotel));
	}*/

	private void assertNotNull(Object addHotel) {
		// TODO Auto-generated method stub
		
	}



	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Ignore
	@Test
	public void testaddHotel() throws HBMSException {
		// increment the number next time you test for positive test case
		hbmsHotel.setAddress("goa");
		hbmsHotel.setCity("hydrabad");
		hbmsHotel.setDescription("best");
		hbmsHotel.setEmail("sheae@gmail.com");
		hbmsHotel.setFax("123456");
		hbmsHotel.setHotel_id("1011");
		hbmsHotel.setHotel_name("taj");
		hbmsHotel.setMobileno("852545625");
		hbmsHotel.setPhone("52545251");
		hbmsHotel.setRate(300.25);
		hbmsHotel.setRating("3.5");
		
		assertTrue("Data Inserted successfully",hbmsHotel,1);
		
	}

	private void assertTrue(String string, HBMSHotel hbmsHotel, int i) {
		// TODO Auto-generated method stub
		System.out.println("Pass");
		
	}
/*
	*//************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************//*

	

	*//********************************************
	 * Test case for retriveAllDetails()
	 ************************************************//*
	@Test
	public void testViewAll() throws beanException {
		assertNotNull(dao.retriveAllDetails());
	}

	*//****************************************************
	 * Test case for viewById()
	 ******************************************************//*

	@Test
	public void testById() throws beanException {
		assertNotNull(dao.viewbeanDetails("1010"));
	}

	@Ignore
	@Test
	public void testById1() throws beanException {
		assertEquals("TestName", dao.viewbeanDetails("1010").getbeanName());
	}

}
*/
/*	
	@Ignore
	@Test
	public void testsearchHotel() throws HBMSException {
		// increment the number next time you test for positive test case
		
		booking.g
		hbmsHotel.setHotel_id("1011");
		
		
		assertTrue("Data Inserted successfully",hbmsHotel,1);
		
	}*/

/*	private void assertTrue(String string, HBMSHotel hbmsHotel, int i) {
		// TODO Auto-generated method stub
		System.out.println("Pass");
		
	}*/
	@Ignore
	@Test
	public void testupdatedes() throws HBMSException {
		// increment the number next time you test for positive test case
		
		hbmsHotel.setDescription("best");
		hbmsHotel.setHotel_id("1011");
		
		
		assertTrue("Data Inserted successfully",hbmsHotel,1);
		
	}
}



