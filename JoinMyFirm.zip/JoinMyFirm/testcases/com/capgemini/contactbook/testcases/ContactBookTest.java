package com.capgemini.contactbook.testcases;

import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

public class ContactBookTest
{

	static EnquiryBean enquiryBean=null;
	static ContactBookService contactBookService=null;
	static Logger logger=Logger.getRootLogger();

	@BeforeClass
	public static void intialize()
	{
		enquiryBean=new EnquiryBean();
		contactBookService=new ContactBookServiceImpl();
	}

	@Test

	//------------------------ 1. Contact Book --------------------------
	/*******************************************************************************************************
				 - Function Name	:	testAddEnquiry()
				 - Input Parameters	:	No Parameter
				 - Return Type		:	Void
				 - Throws		    :   ContactBookException
				 - Author		    :	Ritu Kumari
				 - Creation Date	:	13/09/2017
				 - Description		:	Testing the addEnquiry() method 
	 ********************************************************************************************************/

	public void testAddEnquiry() throws ContactBookException
	{
		enquiryBean.setfName("Richa");
		enquiryBean.setlName("Singh");
		enquiryBean.setContactNo("8116430837");
		enquiryBean.setpDomain("java");
		enquiryBean.setpLocation("Mumbai");

		try 
		{
			assertNotNull(contactBookService.addEnquiry(enquiryBean));
		} catch (ContactBookException e) 
		{
			logger.error("Record Not Inserted");
			throw new ContactBookException("Record Not Inserted");
		}
	}

	@Test
	//------------------------ 1. Contact Book --------------------------
	/*******************************************************************************************************
			 - Function Name	:	testGetEnquiryDetails()
			 - Input Parameters	:	No Parameter
			 - Return Type		:	Void
			 - Throws		    :   ContactBookException
			 - Author		    :	Ritu Kumari
			 - Creation Date	:	13/09/2017
			 - Description		:	Testing the getEnquiryDetails() method 
	 ********************************************************************************************************/
	public void testGetEnquiryDetails() throws ContactBookException
	{
		try {
			enquiryBean=contactBookService.getEnquiryDetails(1001);
			assertEquals("Ritu", enquiryBean.getfName());
			assertEquals("Singh", enquiryBean.getlName());
			assertEquals("1234567890",enquiryBean.getContactNo());
			assertEquals("java", enquiryBean.getpDomain());
			assertEquals("kol", enquiryBean.getpLocation());
		} catch (ContactBookException e)
		{
			logger.error("Record Not Found");
			throw new ContactBookException("Record Not Found");
		}
	}
}
