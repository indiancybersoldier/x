package com.capgemini.contactbook.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.exception.ContactBookException;


public class DBConnection
{
	private static DBConnection dbInstance = null;
	Logger logger=Logger.getRootLogger();
	// step2 create a private constructor
	private DBConnection() {
		PropertyConfigurator.configure("resources/log4j.properties");

	}

	// step3 create a static method which constructs & return the obj
	public static DBConnection getInstance() {
		if (dbInstance == null)
			dbInstance = new DBConnection();
		return dbInstance;

	}

	public Connection getConnection() throws ContactBookException {
		Connection con = null;
		String fileName = "resources/jdbc.properties";
		Properties prop = new Properties();
		try {
			InputStream inStream = new FileInputStream(fileName);
			prop.load(inStream);
			String url = prop.getProperty("dburl");
			String username = prop.getProperty("username");
			String password = prop.getProperty("password");
			con = DriverManager.getConnection(url, username, password);

		} catch (FileNotFoundException e) {
			
			logger.error(e.getMessage());
			throw new ContactBookException(e.getMessage());
		} catch (IOException e) {
			
			logger.error(e.getMessage());
			throw new ContactBookException(e.getMessage());
		} catch (SQLException e) {
			
			logger.error(e.getMessage());
			throw new ContactBookException(e.getMessage());
		}
		return con;
	}
}
