package com.capgemini.contactbook.dao;

/*
 Mapping the Queries
 */
public interface QueryMapper 
{
	public static final String ADD_DETAILS_QUERY="INSERT INTO enquiry VALUES(enquiries.NEXTVAL,?,?,?,?,?)";
	public static final String VIEW_DETAILS_BY_ID="SELECT enqryid,firstname,lastname,contactNo,domain,city FROM enquiry WHERE enqryid=?";
	public static final String ENQUIRYID_QUERY_SEQUENCE = "SELECT enquiries.CURRVAL FROM DUAL";
}
