package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
// importing Logger 
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.util.DBConnection;//


public class ContactBookDaoImpl implements ContactBookDao
{
	Logger logger = Logger.getRootLogger();



	public ContactBookDaoImpl() 
	{
		PropertyConfigurator.configure("resources//log4j.properties");
	}


	//------------------------ 1. Contact Book --------------------------
	/*******************************************************************************************************
		 - Function Name	:	addEnquiry(EnquiryBean enqry)
		 - Input Parameters	:	EnquiryBean enqry
		 - Return Type		:	int
		 - Throws		    :   ContactBookException
		 - Author		    :	Ritu Kumari
		 - Creation Date	:	13/09/2017
		 - Description		:	Adding Details To enquiry Table
	 ********************************************************************************************************/
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		Connection connection=DBConnection.getInstance().getConnection();
		try {

			PreparedStatement preparedStatement=null;
			ResultSet resultSet=null;
			int enquryId=0;
			int rowCount=0;
			preparedStatement=connection.prepareStatement(QueryMapper.ADD_DETAILS_QUERY);
			preparedStatement.setString(1,enqry.getfName());
			preparedStatement.setString(2,enqry.getlName());
			preparedStatement.setString(3,enqry.getContactNo());
			preparedStatement.setString(4,enqry.getpDomain());
			preparedStatement.setString(5,enqry.getpLocation());

			rowCount=preparedStatement.executeUpdate();

			preparedStatement=connection.prepareStatement(QueryMapper.ENQUIRYID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				enquryId=resultSet.getInt(1);
			}
			if(rowCount==0)
			{
				logger.error("Insertion Of Records Failed");
				throw new ContactBookException("Insertion Of Records Failed");
			}
			else
			{
				logger.info("Insertion Of Records Successfull");
				return enquryId;
			}
		}
		catch (ContactBookException e) 
		{
			logger.error("Connection Not Established");
			throw new ContactBookException("Connection Not Established");
		}
		catch (SQLException e)
		{
			logger.error("Insert Query Is Not Fired");
			throw new ContactBookException("Insert Query Is Not Fired");
		}
		finally
		{
			try
			{
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new ContactBookException("Error in closing database connection");

			}
		}

	}
	//------------------------ 1. Contact Book --------------------------
	/*******************************************************************************************************
			 - Function Name	:	getEnquiryDetails(int EnquiryID)
			 - Input Parameters	:	int EnquiryID
			 - Return Type		:	EnquiryBean
			 - Throws		    :   ContactBookException
			 - Author		    :	Ritu Kumari
			 - Creation Date	:	13/09/2017
			 - Description		:	Fetching Details From enquiry Table As per EnquiryId
	 ********************************************************************************************************/

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException
	{
		Connection connection=DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		EnquiryBean enquiryBean=null;
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_DETAILS_BY_ID);
			preparedStatement.setInt(1,EnquiryID);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				enquiryBean=new EnquiryBean();
				enquiryBean.setEnqryId(resultSet.getInt(1));
				enquiryBean.setfName(resultSet.getString(2));
				enquiryBean.setlName(resultSet.getString(3));
				enquiryBean.setContactNo(resultSet.getString(4));
				enquiryBean.setpDomain(resultSet.getString(5));
				enquiryBean.setpLocation(resultSet.getString(6));	
				return enquiryBean;
			}	
		}
		catch (SQLException e)
		{
			logger.error("Insert Query Is Not Fired");
			throw new ContactBookException("Insert Query Is Not Fired");
		}
		finally
		{
			try
			{
				connection.close();
			} 
			catch (SQLException e)
			{
				logger.error(e.getMessage());
				throw new ContactBookException("Error in closing database connection");
			}
		}
		return enquiryBean;
	}

}
