package com.capgemini.contactbook.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
// Service implementation
public class ContactBookServiceImpl implements ContactBookService
{
	ContactBookDao dao=null;

	public ContactBookServiceImpl()
	{
		dao=new ContactBookDaoImpl();
	}

	//------------------------ 1. Contact Book --------------------------
	/*******************************************************************************************************
		 - Function Name	:	addEnquiry(EnquiryBean enqry)
		 - Input Parameters	:	EnquiryBean enqry
		 - Return Type		:	int
		 - Throws		    :   ContactBookException
		 - Author		    :	Ritu Kumari
		 - Creation Date	:	13/09/2017
		 - Description		:	Calling the Dao Layer Method And Returning Value To Calling Method
	 ********************************************************************************************************/
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException
	{

		return dao.addEnquiry(enqry);
	}

	//------------------------ 1. Contact Book --------------------------
	/*******************************************************************************************************
			 - Function Name	:	getEnquiryDetails(int EnquiryID)
			 - Input Parameters	:	int EnquiryID
			 - Return Type		:	EnquiryBean
			 - Throws		    :   ContactBookException
			 - Author		    :	Ritu Kumari
			 - Creation Date	:	13/09/2017
			 - Description		:	Calling the Dao Layer Method And Returning Value To Calling Method
	 ********************************************************************************************************/
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException
	{

		return dao.getEnquiryDetails(EnquiryID);
	}

	//------------------------ 1. Contact Book --------------------------
	/*******************************************************************************************************
			 - Function Name	:	isValidEnquiry(EnquiryBean enqry) 
			 - Input Parameters	:	EnquiryBean enqry
			 - Return Type		:	boolean
			 - Throws		    :   ContactBookException
			 - Author		    :	Ritu Kumari
			 - Creation Date	:	13/09/2017
			 - Description		:	Validating The Inputs Given By The User
	 ********************************************************************************************************/
	@Override
	public boolean isValidEnquiry(EnquiryBean enqry) 
	{

		List<String>errorList=new ArrayList<String>();
		if(!(validateContactNo(enqry.getContactNo())))
		{
			errorList.add("\nEnter Valid Mobile Number");
		}
		if(!(validateFirstName(enqry.getfName())))
		{
			errorList.add("\nFirst Name Cannot Be Empty");
		}
		if(!(validateLastName(enqry.getlName())))
		{
			errorList.add("\nLast Name Cannot Be Empty");
		}
		if(!(validatePLocation(enqry.getpLocation())))
		{
			errorList.add("\nPreferred Location Cannot Be Empty");
		}
		if(!(validatePDomain(enqry.getpDomain())))
		{
			errorList.add("\nPreferred Domain Cannot Be Empty");
		}
		if(!(errorList.isEmpty()))
		{
			return false ;
		}
		else
			return true;
	}

	// Validations
	public boolean validateContactNo(String contactNo)
	{
		Pattern contactPattern=Pattern.compile("^[0-9]{10}$");
		Matcher contactMatcher=contactPattern.matcher(contactNo);
		return contactMatcher.matches();
	}
	public boolean validateFirstName(String fName)
	{
		Pattern firstPattern=Pattern.compile("^[A-Za-z]$");
		Matcher firstMatcher=firstPattern.matcher(fName);

		if((fName.length()==0)&&(firstMatcher.matches()==false))
			return false;
		else
			return true;
	}
	public boolean validateLastName(String lName)
	{
		Pattern lastPattern=Pattern.compile("^[A-Za-z]$");
		Matcher lastMatcher=lastPattern.matcher(lName);
		if((lName.length()==0)&&(lastMatcher.matches()==false))
			return false;
		else
			return true;
	}
	public boolean validatePLocation(String pLocation)
	{
		Pattern locationPattern=Pattern.compile("^[A-Za-z]$");
		Matcher locationMatcher=locationPattern.matcher(pLocation);
		if((pLocation.length()==0)&&(locationMatcher.matches()==false))
			return false;
		else
			return true;
	}
	public boolean validatePDomain(String pDomain)
	{
		Pattern domainPattern=Pattern.compile("^[A-Za-z]$");
		Matcher domainMatcher=domainPattern.matcher(pDomain);
		if((pDomain.length()==0)&&(domainMatcher.matches()==false))
			return false;
		else
			return true;
	}

}
