package com.capgemini.contactbook.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

// Menu driven client
public class Client 
{
	static Logger logger=Logger.getRootLogger();
	static EnquiryBean enquiryBean=null;
	static Scanner scanner=new Scanner(System.in);
	static ContactBookService contactBookService=null;
		
	
	public Client()
	{
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	public static void main(String[] args) throws ContactBookException
	{
		
  // Client cl = new Client();
   displayMenu();

	}
	
	public static EnquiryBean populateEnquiryBean() throws ContactBookException
	{
		contactBookService=new ContactBookServiceImpl();
		enquiryBean=new EnquiryBean();
		
		System.out.println("Enter First Name");
		enquiryBean.setfName(scanner.next());
		
		System.out.println("Enter Last Name");
		enquiryBean.setlName(scanner.next());
		
		System.out.println("Enter Contact Number");
		enquiryBean.setContactNo(scanner.next());
		
		System.out.println("Enter Preferred Domain");
		enquiryBean.setpDomain(scanner.next());
		
		System.out.println("Enter Preferred Location");
		enquiryBean.setpLocation(scanner.next());
		
		if(contactBookService.isValidEnquiry(enquiryBean))
		{
			return enquiryBean;
		}
		else
		{
			System.err.println("Not A Valid Input");
			return null;
		}	
	}
	
	public static void displayMenu() throws ContactBookException
	{
		int choice=1;
		int enquiryId=0;
		while(choice!=0)
		{
			System.out.println("*********************Global Recruitments*********************");
			System.out.println("Choose an Operation");
			System.out.println("1.Enter Enquiry Details");
			System.out.println("2.View Enquiry Details On Id");
			System.out.println("0.Exit");
			System.out.println("*********************");
			System.out.println("Please enter a choice: ");
			choice=scanner.nextInt();
			switch(choice)
			{
				case 0: System.out.println("Thank you for selecting us!!");
						System.exit(0);
				break;
				
				case 1: enquiryBean=populateEnquiryBean();
						if(enquiryBean!=null)
						{
						contactBookService=new ContactBookServiceImpl();
						enquiryId=contactBookService.addEnquiry(enquiryBean);
						System.out.println("Thank You "+enquiryBean.getfName()+" "+enquiryBean.getlName()+" your Unique Id is "+enquiryId+" we will contact you shortly");
						}
						else
						{
							logger.error("You Are Not Registered");
							System.err.println("You Are Not Registered");
							System.err.println("Try Again");
							System.out.println("\n\n\n");
							displayMenu();
							
						}
				break;
				
				case 2: contactBookService=new ContactBookServiceImpl();
						System.out.println("Enter the Enquiry No.: ");
						enquiryId=scanner.nextInt();
						enquiryBean=contactBookService.getEnquiryDetails(enquiryId);
						if(enquiryBean!=null)
						{	
						System.out.println("ID"+"          "+"First Name"+"          "+"Last Name"+"          "+"Contact No."+"          "+"Preferred Domain"+"          "+"Preferred Location");
						System.out.print(enquiryBean.getEnqryId()+"          "+enquiryBean.getfName()+"          "+enquiryBean.getlName()+"          "+enquiryBean.getContactNo()+"          "+enquiryBean.getpDomain()+"          "+enquiryBean.getpLocation());
						System.out.println("\n\n\n\n");
						}
						else
							System.out.println("Sorry no details found!!\n\n\n");
				break;
				
				default: System.out.println("Enter Correct Choice");
				break;
			}
		}
	}

}
