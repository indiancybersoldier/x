package com.cg.presentation;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.Service.InsPurchaseDetails;
import com.cg.Service.MobDetails;

public class MobileDetails {

	
	public static void main(String... args){
	
	
		Scanner sc = new Scanner(System.in);
		System.out.println("Choose valid option ");
		System.out.println("1.Insert customer and purchase details : ");
		System.out.println("2.View Details Of all Mobile Available in Shop : ");
		System.out.println("3.Delete Mobile : ");
		System.out.println("4.Search Mobile based on price range : ");
		int n=0;
		n=sc.nextInt();
		switch(n)
		{
		case 1:
			try {
				new InsPurchaseDetails().insDetails();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
		case 2:try {
					MobDetails.getDetails();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			break;
		case 3:
			break;
		case 4:
		break;
		default:
		}
	}
}
/*CREATE SEQUENCE customers_seq
START WITH     1000
INCREMENT BY   1
NOCACHE
NOCYCLE;*/