package com.cg.Service;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.dataObjects.Myconnection;;

public class MobDetails {
	public static void getDetails() throws SQLException{
		Connection con=Myconnection.getConnection();
		Statement stmt = con.createStatement (ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); 
		ResultSet rset = stmt.executeQuery ("select * from mobiles");
		System.out.println("_______________________________________");
		while (rset.next()) {
			System.out.println (rset.getInt (1)+"       "+rset.getString (2)+"  "+rset.getDouble (3)+"    "+rset.getString (4));

		}

		
		
	}
}
