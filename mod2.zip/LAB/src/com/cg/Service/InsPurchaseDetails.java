package com.cg.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Scanner;

import com.cg.dataObjects.Myconnection;

public class InsPurchaseDetails {
	public void insDetails() throws SQLException{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Customer Name");
		String cname=new String(sc.nextLine());
		System.out.println("Enter Customer's Email");
		String email=new String(sc.nextLine());
		System.out.println("Enter mobileId");
		boolean validId=false;
		int id=sc.nextInt();
		System.out.println("Enter Customer Number");
		sc.nextLine();
		String phn=new String(sc.nextLine());
		//System.out.println(cname+email+id+phn);	
		Connection conn=Myconnection.getConnection();
		Statement stmt= conn.createStatement();
		int purchaseid=0;
		ResultSet rs =null;
		rs = stmt.executeQuery("SELECT mobileid FROM MOBILES"); 
		while(rs.next())
		{
			int m=rs.getInt(1);
			if(m==id)
			{
				validId=true;
				break;
			}
		}
		if(validId==false)
		{
			System.out.println("EXITING");
			System.exit(0);
			
		}
		else
		{
			stmt.executeQuery("UPDATE mobiles SET quantity = quantity - 1 where mobileid ="+id);
		 rs = stmt.executeQuery("SELECT customers_seq.NEXTVAL FROM dual");
		 

		if ( rs!=null && rs.next() ) {
		 purchaseid = rs.getInt(1);
		//System.out.println("snvsdvlskjlsvd   "+cust_id);
		rs.close();
		}
		if(purchaseid!=0){
			PreparedStatement pstmt = conn.prepareStatement("insert into purchasedetails values(?,?,?,?,?,?)"); 
			pstmt.setInt(1, purchaseid);
			pstmt.setString(2,cname);
			pstmt.setString(3,email);
			pstmt.setString(4,phn);
			LocalDate d = LocalDate.now();
			pstmt.setDate(5,java.sql.Date.valueOf(d));
			pstmt.setInt(6,id);
			
			int count=pstmt.executeUpdate();
					if(count>0)
					{
						System.out.println("Done");
						System.out.println("Record is inserted successfully !!");
					}
			
			
			
		}
		
	}
}
}
