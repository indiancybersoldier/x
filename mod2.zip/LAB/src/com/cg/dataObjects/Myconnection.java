package com.cg.dataObjects;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Myconnection {
	public static Connection getConnection() {
		Properties props = new Properties();
		FileInputStream fis = null;
		Connection con = null;
		try {
			
			fis = new FileInputStream("C:/Users/Dell/Desktop/db.properties");
			props.load(fis);
		int c=	fis.read();
		System.out.println("going in");
		while(c!=-1)
		{
			System.out.println("into in");
			System.out.println(c);
			c=fis.read();
		}
			System.out.println(props.getProperty("DB_URL")+"  ");
			// load the Driver Class
			DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
			// create the connection now
			con = DriverManager.getConnection(props.getProperty("DB_URL"),
					props.getProperty("DB_USERNAME"),
					props.getProperty("DB_PASSWORD"));
		} catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
/*	public static Connection getConnection(){
		Connection conn = null;
		
		try {
			 	
				DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
				conn = 
						DriverManager.getConnection (
								"jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "orcl11g");
		 	} catch (SQLException e) {
		 		e.printStackTrace();
		}

		return conn;
		
	}*/
}
/*****
FOR PROPERTIES FILE
Properties props = new Properties();
FileInputStream in = new FileInputStream("/external/configuration/dir/db.properties");
props.load(in);
in.close();

String driver = props.getProperty("jdbc.driver");
if (driver != null) {
    Class.forName(driver) ;
}

String url = props.getProperty("jdbc.url");
String username = props.getProperty("jdbc.username");
String password = props.getProperty("jdbc.password");

Connection con = DriverManager.getConnection(url, username, password);

PROPERTIES FILE CONTENT

# Oracle DB properties
#jdbc.driver=oracle.jdbc.driver.OracleDriver
#jdbc.url=jdbc:oracle:thin:@localhost:1521:XE
#jdbc.username=system
#jdbc.password=orcl11g

**************/