package com.cg.dataObjects;

public class Mobile {

}
