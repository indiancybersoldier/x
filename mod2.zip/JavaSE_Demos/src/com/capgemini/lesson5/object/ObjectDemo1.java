package com.capgemini.lesson5.object;

public class ObjectDemo1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object obj1=new Object();
		Object obj2=new Object();
		System.out.println(obj1.hashCode());
		System.out.println(obj2.hashCode());
	}

}
