package com.capgemini.lesson3.iteration;

public class WhileEg {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		while(i<10)
		{
	        System.out.println(i + " ");
	        i++;
	    }
	}

}
