CREATE TABLE Traininfo
(
trainId VARCHAR(6) PRIMARY KEY,
trainName VARCHAR2(20) UNIQUE,
destination VARCHAR2(20),
journeyDate DATE,
trainfare NUMBER(7,2),
seats NUMBER(4)
);


INSERT INTO Traininfo values('S1500','Saktipunj','Delhi',TO_DATE('17/9/2017', 'DD/MM/YYYY'),800,52);
INSERT INTO Traininfo values('S1600','Garibrath','Delhi',TO_DATE('18/9/2017', 'DD/MM/YYYY'),590,50);
INSERT INTO Traininfo values('S1700','Coalfield','Delhi',TO_DATE('19/9/2017', 'DD/MM/YYYY'),560,55);
INSERT INTO Traininfo values('S1800','Blackdiamond','Delhi',TO_DATE('20/9/2017', 'DD/MM/YYYY'),560,53);
INSERT INTO Traininfo values('S1400','Rajdhanni','Delhi',TO_DATE('15/9/2017', 'DD/MM/YYYY'),540,52);
INSERT INTO Traininfo values('S1300','Duranto','Delhi',TO_DATE('22/9/2017', 'DD/MM/YYYY'),503,50);