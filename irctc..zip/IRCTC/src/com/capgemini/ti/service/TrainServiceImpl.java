package com.capgemini.ti.service;

import java.util.List;

import com.capgemini.ti.bean.TrainBean;
import com.capgemini.ti.dao.TrainDAO;
import com.capgemini.ti.dao.TrainDAOImpl;
import com.capgemini.ti.exception.TrainException;

public class TrainServiceImpl implements TrainService {
	TrainDAO dao = new TrainDAOImpl();

	@Override
	public List<TrainBean> getAllTrain() throws TrainException {
		List<TrainBean> list = dao.getAllTrain();
		return list;
	}

	@Override
	public void makeBooking(String trainId, int noOfSeats)
			throws TrainException {
		// TODO Auto-generated method stub
		dao.makeBooking(trainId, noOfSeats);
		
	}

	@Override
	public TrainBean getTrain(String trainId) throws TrainException {
		TrainBean bean = new TrainBean();
		bean=dao.getTrain(trainId);
		return bean;
	}

	@Override
	public void addTrain(TrainBean dto) throws TrainException {
		// TODO Auto-generated method stub
		dao.addTrain(dto);
		
	}
	

}
