package com.capgemini.ti.controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.ti.bean.TrainBean;
import com.capgemini.ti.exception.TrainException;
import com.capgemini.ti.service.TrainServiceImpl;

/**
 * Servlet implementation class TrainServlet
 */
@WebServlet("*.obj")
public class TrainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TrainServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		TrainServiceImpl service = null;
		TrainBean bean = null;
		String target = "";

		HttpSession session = request.getSession(true);
		// Object creations
		bean = new TrainBean();
		service = new TrainServiceImpl();
		
		String targetSuccess = "success.jsp";
		String targetViewAll = "viewAllTrains.jsp";
		String targetError = "error.jsp";
		String targetHome = "index.jsp";
		String targetBook = "book.jsp";
		String targetSearch = "search.jsp";
		String targetView = "viewtrain.jsp";
		String targetInsert ="insert.jsp";
		
		String path = request.getServletPath().trim();

		switch (path) {

		case "/Home.obj":
			session.setAttribute("error", null);
			session.setAttribute("bean", null);
			target = targetHome;
			break;
		
		case "/insert.obj":
			target =targetInsert;
			bean=new TrainBean();
			String trainId=request.getParameter("trainno");
			String trainName=request.getParameter("trainName");
			String destination=request.getParameter("destination");
			Date date=java.sql.Date.valueOf(request.getParameter("journeyDate"));
			Double fare = Double.parseDouble(request.getParameter("fare"));
			Integer noofSeats = Integer.parseInt(request.getParameter("noOfSeats"));
			
			bean.setTrainId(trainId);
			bean.setTrainName(trainName);
			bean.setDestination(destination);
			bean.setJourneyDate(date);
			bean.setNumberOfSeats(noofSeats);
			bean.setFare(fare);
			System.out.println(bean);
			
			
			
			try {
				
				service.addTrain(bean);
				//out.println("Done");
				//RequestDispatcher dispatcher = request.getRequestDispatcher("Display.jsp");
				//dispatcher.forward(request, response);
				
				
				
				}
				
				
				
			 catch (TrainException e) {
				
				System.out.println("Failure");
			
			}
			
			break;
		case "/searchById.obj":
			
			target=targetSearch;
			break;
	
		case "/viewTrain.obj":
			bean=new TrainBean();
			trainId = request.getParameter("trainId");
			try {
				bean = service.getTrain(trainId);
				System.out.println("tyryuf");
				
				if (bean.getTrainId()==null) {
					System.out.println("empty block");
					session.setAttribute("bean", null);
					session.setAttribute("error","Sorry No data Found for given ID!");
					target = targetError;
				} else {
					System.out.println("empty block else");
					session.setAttribute("error", null);
					session.setAttribute("bean", bean);
					target = targetView;
				}
				
			} catch (TrainException e) {
				System.out.println("tyryuf");
				session.setAttribute("error", e.getMessage());
				target = targetError;
			}


			break;
			
		
		case "/book.obj":
			session.setAttribute("name", request.getParameter("name"));
			session.setAttribute("fare", request.getParameter("fare"));
			session.setAttribute("availseats", request.getParameter("availseats"));
			session.setAttribute("trainid", request.getParameter("trainid"));
			target = targetBook;
			break;
			
		case "/success.obj":
			String passangerName=request.getParameter("pname");
			String mobileNo = request.getParameter("mobile");
			Integer noOfSeats = Integer.parseInt(request.getParameter("bookseat"));
			trainId=(String)session.getAttribute("trainid");
			
			session.setAttribute("passangerName", passangerName);
			session.setAttribute("mobileNo", mobileNo);
			session.setAttribute("noOfSeats", noOfSeats);
			
			try {
				service.makeBooking(trainId, noOfSeats);
			} catch (TrainException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			target = targetSuccess;
			break;
		
		case "/ViewAllTrains.obj":
			List<TrainBean> beanList = null;
			try {
				beanList = service.getAllTrain();
			} catch (TrainException e) {
				session.setAttribute("error", e.getMessage());
				target = targetError;
			}
			if (!beanList.isEmpty()) {
				session.setAttribute("error", null);
				session.setAttribute("beanList", beanList);
				target = targetViewAll;
			} else {
				session.setAttribute("beanList", null);
				session.setAttribute("error", "Sorry No data Found!");
				target = targetViewAll;
			}

			break;
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);

		
	}

	}
