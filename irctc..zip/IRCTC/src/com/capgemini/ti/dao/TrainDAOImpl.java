package com.capgemini.ti.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.ti.bean.TrainBean;
import com.capgemini.ti.exception.TrainException;
import com.capgemini.ti.util.DbConnection;

public class TrainDAOImpl implements TrainDAO{

	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;
	
	@Override
	public List<TrainBean> getAllTrain() throws TrainException {
		List<TrainBean> list = new ArrayList<TrainBean>();
		TrainBean bean = new TrainBean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(QueryMapper.VIEWALL);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				bean.setTrainId(resultSet.getString(1));
				bean.setTrainName(resultSet.getString(2));
				bean.setDestination(resultSet.getString(3));
				bean.setJourneyDate(resultSet.getDate(4));
				bean.setFare(resultSet.getDouble(5));
				bean.setNumberOfSeats(resultSet.getInt(6));
				list.add(bean);
				bean = new TrainBean();
			}
		} catch (SQLException e) {
			throw new TrainException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new TrainException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new TrainException(
						"Could not close the connection");
			}
		}
		return list;
	}

	@Override
	public void makeBooking(String trainId, int noOfSeats) throws TrainException {
		// TODO Auto-generated method stub
		try{
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(QueryMapper.UPDATESEATS);
			preparedStatement.setString(2, trainId);
			preparedStatement.setInt(1, noOfSeats);
			
			preparedStatement.executeUpdate();			
		}
		catch (SQLException e) {
			throw new TrainException("Error while database interaction:::"
					+ e.getMessage());
		
		
	}
	
	}

	@Override
	public TrainBean getTrain(String trainId) throws TrainException {
		TrainBean bean = new TrainBean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement(QueryMapper.SEARCH);
			preparedStatement.setString(1, trainId);
			resultSet = preparedStatement.executeQuery();
			
			
			while (resultSet.next()) {
				bean.setTrainId(resultSet.getString(1));
				bean.setTrainName(resultSet.getString(2));
				bean.setDestination(resultSet.getString(3));
				bean.setJourneyDate(resultSet.getDate(4));
				bean.setFare(resultSet.getDouble(5));
				bean.setNumberOfSeats(resultSet.getInt(6));
				
			}

		} catch (SQLException e) {
			throw new TrainException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new TrainException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new TrainException(
						"Could not close the connection");
			}
		}
		return bean;
	}

	@Override
	public void addTrain(TrainBean dto) throws TrainException {
		// TODO Auto-generated method stub
		try{
			conn = DbConnection.getConnection();
		System.out.println(dto.getTrainId());
			preparedStatement = conn.prepareStatement(QueryMapper.INSERT_TRAIN);
			preparedStatement.setString(1, dto.getTrainId());
			preparedStatement.setString(2, dto.getTrainName());
			preparedStatement.setString(3, dto.getDestination());
			preparedStatement.setDate(4, dto.getJourneyDate());
			preparedStatement.setInt(5, dto.getNumberOfSeats());
			preparedStatement.setDouble(6, dto.getFare());
			
			preparedStatement.executeUpdate();
		
		}catch (SQLException e) {
			throw new TrainException("dao/sql/ERROR:"
					+ e.getMessage());
		} catch (Exception e) {
			throw new TrainException("ERROR:" + e.getMessage());
		} finally {
			try {
				if (conn != null) {
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} catch (Exception e) {
				throw new TrainException(
						"Could not close the connection");
			}
			
		}
		
	}

	
	}
