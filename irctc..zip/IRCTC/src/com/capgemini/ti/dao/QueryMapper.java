package com.capgemini.ti.dao;

public interface QueryMapper {
	String VIEWALL = "SELECT * FROM Traininfo";
	String UPDATESEATS = "UPDATE Traininfo SET seats=seats-? WHERE trainId=?";
	String SEARCH="SELECT * FROM Traininfo WHERE trainId=?";
	String INSERT_TRAIN ="INSERT INTO Traininfo values(?,?,?,?,?,?)";
}
