package com.capgemini.ti.dao;

import java.util.List;

import com.capgemini.ti.bean.TrainBean;
import com.capgemini.ti.exception.TrainException;

public interface TrainDAO {
	public List<TrainBean> getAllTrain()throws TrainException;
	
	public void makeBooking(String trainId, int noOfSeats)	throws TrainException;
	
	public TrainBean getTrain(String trainId) throws TrainException;
	
	public void addTrain(TrainBean dto) throws TrainException;

}
