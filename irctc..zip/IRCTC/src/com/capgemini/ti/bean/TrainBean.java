package com.capgemini.ti.bean;

import java.sql.Date;

public class TrainBean {
	private String trainId;
	private String trainName;
	private String destination;
	private Date journeyDate;
	private int numberOfSeats;
	private double fare;
	
	public TrainBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TrainBean(String trainId, String trainName, String destination,
			Date journeyDate, int numberOfSeats, double fare) {
		super();
		this.trainId = trainId;
		this.trainName = trainName;
		this.destination = destination;
		this.journeyDate = journeyDate;
		this.numberOfSeats = numberOfSeats;
		this.fare = fare;
	}

	public String getTrainId() {
		return trainId;
	}

	public void setTrainId(String trainId) {
		this.trainId = trainId;
	}

	public String getTrainName() {
		return trainName;
	}

	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Date getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(Date journetDate) {
		this.journeyDate = journetDate;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

	public double getFare() {
		return fare;
	}

	public void setFare(double fare) {
		this.fare = fare;
	}

	@Override
	public String toString() {
		return "TrainBean [trainId=" + trainId + ", trainName=" + trainName
				+ ", destination=" + destination + ", journeyDate="
				+ journeyDate + ", numberOfSeats=" + numberOfSeats + ", fare="
				+ fare + "]";
	}

	
}
