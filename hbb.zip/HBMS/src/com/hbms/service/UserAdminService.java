package com.hbms.service;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hbms.bean.BookingBean;
import com.hbms.bean.HotelBean;
import com.hbms.bean.RoomBean;
import com.hbms.dao.IUserAdminDao;

@Service
public class UserAdminService implements IUserAdminService {

	@Autowired
	IUserAdminDao adminDao;

	@Override
	public boolean addHotel(HotelBean hotelBean) {

		boolean flag = adminDao.addHotel(hotelBean);

		return flag;
	}

	@Override
	public void updatedes(HotelBean hotelId) {

		adminDao.updatedes(hotelId);
	}

	@Override
	public HotelBean getHotelDetails(String hotelId) {

		return adminDao.getHotelDetails(hotelId);
	}

	@Override
	public List<HotelBean> viewAllHotel() {
		List<HotelBean> list = adminDao.viewAllHotel();

		return list;
	}

	@Override
	public HotelBean deletehotel(String hotelId) {
		// TODO Auto-generated method stub
		return adminDao.deletehotel(hotelId);
	}

	@Override
	public List<Object[]> viewGuest(String hotelId) {
		// TODO Auto-generated method stub
		return adminDao.viewGuest(hotelId);
	}

	@Override
	public List<Object[]> viewByDate(Date bookedFrom) {
		// TODO Auto-generated method stub
		return adminDao.viewByDate(bookedFrom);
	}

	@Override
	public List<HotelBean> viewAllHotels() {
		// TODO Auto-generated method stub
		List<HotelBean> list = adminDao.viewAllHotels();
		return list;
	}

	@Override
	public List<BookingBean> getBookingDetails(String id) {
		// TODO Auto-generated method stub
		return adminDao.getBookingDetails(id);
	}

	@Override
	public List<RoomBean> viewAllRooms() {
		// TODO Auto-generated method stub
		List<RoomBean> list = adminDao.viewAllRooms();
		return list;

	}

	@Override
	public List<HotelBean> deleteRoom(String hotelId) {
		// TODO Auto-generated method stub
		return adminDao.deleteRoom(hotelId);
		
	}

	@Override
	public List<Object[]> getType(String hotelId) {
		// TODO Auto-generated method stub
		return adminDao.getType(hotelId);
	}

	@Override
	public List<Object[]> getAllRooms(String hotelId, String roomType) {
		// TODO Auto-generated method stub
		return adminDao.getAllRooms(hotelId,roomType);
	}

	@Override
	public List<Object[]> updateRoom(String hotelId, String roomType,
			String roomNo, double rate) {
		// TODO Auto-generated method stub
		return adminDao.updateRoom(hotelId,roomType,roomNo,rate);
	}
     @Override
	public boolean addRoom(RoomBean roomBean) {
    boolean flag =  adminDao.addRoom(roomBean);
		
		return flag;
	}
}
