package com.hbms.service;

import java.util.List;

import com.hbms.bean.BookingBean;
import com.hbms.bean.HotelBean;
import com.hbms.exception.HbmsException;

public interface IUserCustomerService {

	public List<HotelBean> getAllHotels() throws HbmsException;

	public HotelBean getHotel(String id) throws HbmsException;

	public List<Object[]> getType(String id) throws HbmsException;

	public long getNoOfRooms(String id, String type) throws HbmsException;

	public List<Object[]> getRoomDetails(String id, String type) throws HbmsException;

	public BookingBean bookRooms(BookingBean bean) throws HbmsException;

	public String getUsername(String userId) throws HbmsException;

}
