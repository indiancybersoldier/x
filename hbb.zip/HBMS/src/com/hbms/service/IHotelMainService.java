package com.hbms.service;

import java.util.List;

import com.hbms.bean.UserBean;
import com.hbms.exception.HbmsException;

public interface IHotelMainService {

	boolean registerCustomer(UserBean bean) throws HbmsException;
	public List<UserBean> validate(String id,String password)  throws HbmsException;
}
