package com.hbms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hbms.bean.UserBean;
import com.hbms.dao.IHotelMainDao;
import com.hbms.exception.HbmsException;

@Service
public class HotelMainService implements IHotelMainService{

	@Autowired
	IHotelMainDao mainDao;

	@Override
	public boolean registerCustomer(UserBean bean) throws HbmsException {
		boolean flag=mainDao.registerCustomer(bean);
		return flag;
	}

	@Override
	public List<UserBean> validate(String id, String password)
			throws HbmsException {
		// TODO Auto-generated method stub
		return mainDao.validate(id,password);
	}
}
