package com.hbms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hbms.bean.BookingBean;
import com.hbms.bean.HotelBean;
import com.hbms.dao.IUserCustomerDao;
import com.hbms.exception.HbmsException;

@Service
public class UserCustomerService implements IUserCustomerService{

	@Autowired
	IUserCustomerDao customerDao;

	@Override
	public List<HotelBean> getAllHotels() throws HbmsException {
		// TODO Auto-generated method stub
		return customerDao.getAllHotels();
	}

	@Override
	public HotelBean getHotel(String id) throws HbmsException {
		// TODO Auto-generated method stub
		return customerDao.getHotel(id);
	}

	@Override
	public List<Object[]> getType(String id) throws HbmsException {
		// TODO Auto-generated method stub
		return customerDao.getType(id);
	}

	@Override
	public long getNoOfRooms(String id, String type) throws HbmsException {
		// TODO Auto-generated method stub
		return customerDao.getNoOfRooms(id,type);
	}

	@Override
	public List<Object[]> getRoomDetails(String id, String type)
			throws HbmsException {
		// TODO Auto-generated method stub
		return customerDao.getRoomDetails(id,type);
	}

	@Override
	public BookingBean bookRooms(BookingBean bean) throws HbmsException {
		// TODO Auto-generated method stub
		return customerDao.bookRooms(bean);
	}

	@Override
	public String getUsername(String userId) throws HbmsException {
		// TODO Auto-generated method stub
		return customerDao.getUsername(userId);
	}
}
