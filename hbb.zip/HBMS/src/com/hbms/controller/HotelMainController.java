package com.hbms.controller;



import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hbms.bean.HotelBean;
import com.hbms.bean.UserBean;
import com.hbms.exception.HbmsException;
import com.hbms.service.IHotelMainService;
import com.hbms.service.IUserAdminService;

@Controller
public class HotelMainController {

	ModelAndView model= new ModelAndView();
	@Autowired
	IHotelMainService hotelMainService;
	
	@Autowired 
	IUserAdminService adminService;
	
	@RequestMapping("home")
	public String home()
	{
		
		return "Home";
	}
	
	@RequestMapping("registrationForm")
	public String showregistrationForm(){
		return("Registration");
	}
	

	@RequestMapping("/success")
	public ModelAndView addTrainee(UserBean bean,BindingResult result) throws HbmsException
	{
		ModelAndView mv = new ModelAndView();
		if(result.hasErrors())
		{
			mv.setViewName("error");
			mv.addObject("message","Binding error");
		}
		else{
			
			hotelMainService.registerCustomer(bean);
			
			mv.setViewName("RegistrationSuccess");
			mv.addObject("UserForm", bean);
		}
		
		return mv;
		
	}
	@RequestMapping("loginForm")
	public String showLoginForm(){
		return("Login");
	}
	@RequestMapping("/login")
	public ModelAndView validate(@RequestParam("userId") String id, @RequestParam("password") String password) throws HbmsException
	{
	
		
		List<UserBean> userDetails = hotelMainService.validate(id,password);
		if(userDetails.isEmpty())
		{
			model.setViewName("error");
			model.addObject("message", "Invalid Login");
		}
		
		else
		{	String role="";
			for(UserBean u:userDetails)
			{
				role=u.getRole();
				
				if(role.equals("customer"))
				{	
					
					model.addObject("userDetails",userDetails);
					model.setViewName("redirect:/customer/CustomerHome.obj");
				}
				if(role.equals("admin"))
				{
					List<HotelBean> list = adminService.viewAllHotel();
					//model.addObject("userDetails",userDetails);
					model.addObject("hotellist",list);
					model.setViewName("redirect:/admin/Home.obj");
					return model;
					
				}
			}
			
		}
		return model;
		
	}
	
	
}
