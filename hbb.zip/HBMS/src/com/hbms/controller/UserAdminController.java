package com.hbms.controller;

import java.sql.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hbms.bean.BookingBean;
import com.hbms.bean.HotelBean;
import com.hbms.bean.RoomBean;
import com.hbms.service.IUserAdminService;

@Controller
@RequestMapping("admin")
public class UserAdminController {

	@Autowired
	IUserAdminService adminService;

	@RequestMapping("Hotelform")
	public String showPage() {
		return "Hotelform";
	}

	@RequestMapping("Home")
	public ModelAndView viewAllHotels() {
		List<HotelBean> list = adminService.viewAllHotel();
		ModelAndView model = new ModelAndView("adminhome");
		model.addObject("hotellist", list);
		return model;
	}

	@RequestMapping("delete")
	public ModelAndView delete(@RequestParam("hotelId") String hotelId) {

		adminService.deletehotel(hotelId);
		List<HotelBean> list = adminService.viewAllHotel();
		ModelAndView model = new ModelAndView("adminhome");
		model.addObject("hotellist", list);
		return model;
	}

	@RequestMapping("successhotel")
	public ModelAndView addhotel(@Valid HotelBean hotelBean,
			BindingResult result) {
		ModelAndView model = new ModelAndView();
		if (result.hasErrors()) {
			model.setViewName("Hotelform");
		} else {
			adminService.addHotel(hotelBean);
			model.setViewName("adminhome");
			model.addObject("hotel", hotelBean);
		}
		
		return model;
	}

	@RequestMapping("updatehotel")
	public ModelAndView getDetails(@RequestParam("hotel") String hotelId) {
		HotelBean hotelBean = new HotelBean();
		hotelBean = adminService.getHotelDetails(hotelId);
		ModelAndView mv = new ModelAndView("updatehotel");
		mv.addObject("hotel", hotelBean);
		return mv;
	}

	@RequestMapping("done")
	public ModelAndView success(@ModelAttribute("Hotel") HotelBean hotelBean) {
		adminService.updatedes(hotelBean);
		ModelAndView mv = new ModelAndView("redirect:/admin/Home.obj");
		/*mv.addObject("hotel", hotelBean);
		mv.addObject("msg", "Updated Successfully");*/
		return mv;
	}



	@RequestMapping("getguest")
	public String showguestForm() {
		return ("getguest");
	}



	@RequestMapping("/view")
	public ModelAndView viewAllHotels2() {
		List<HotelBean> list = adminService.viewAllHotels();
		ModelAndView model = new ModelAndView();

		if (list.isEmpty()) {
			String msg = "No Hotels to Show";
			model.setViewName("myError");
			model.addObject("msg", msg);
		} else {
			model = new ModelAndView("viewpage");
			model.addObject("hotellist", list);
			return (model);
		}
		return model;
	}

	@RequestMapping("/book")
	public ModelAndView viewBookingById(@RequestParam("id") String id) {

		List<BookingBean> list1 = adminService.getBookingDetails(id);
		ModelAndView model = new ModelAndView();
		if (list1.isEmpty()) {
			String msg = "Still Now no Bookings For This Hotel";
			model.setViewName("myError");
			model.addObject("msg", msg);
		} else {
			model = new ModelAndView("bookings");
			model.addObject("booking", list1);
			return (model);
		}
		return model;
	}

	@RequestMapping("/guest")
	public ModelAndView viewGuest2(@RequestParam("hotelId") String hotelId) {

		List<Object[]> list1 = adminService.viewGuest(hotelId);
		for (Object[] x : list1) {
			System.out.println(x[1]);
		}
		ModelAndView model = new ModelAndView();
		if (list1.isEmpty()) {
			String msg = "Still Now No GuestList for this Hotel";
			model.setViewName("myError");
			model.addObject("msg", msg);
		} else {
			model = new ModelAndView("byguest");
			model.addObject("guest", list1);
			return (model);
		}
		return model;
	}

	@RequestMapping("/viewguest")
	public ModelAndView viewAllGuests() {
		List<HotelBean> list = adminService.viewAllHotels();
		ModelAndView model = new ModelAndView();

		if (list.isEmpty()) {
			String msg = "No Hotels to Show";
			model.setViewName("myError");
			model.addObject("msg", msg);
		} else {
			model = new ModelAndView("viewpage2");
			model.addObject("hotellist", list);
			return (model);
		}
		return model;
	}

	@RequestMapping("dateForm")
	public String showdateForm() {
		return ("date");
	}
	
	@RequestMapping("/date")
	public ModelAndView viewByDate2(@RequestParam("date") Date bookedFrom) {
		
		List<Object[]> list1 = adminService.viewByDate(bookedFrom);
		System.out.println(list1);
		ModelAndView model = new ModelAndView();
		if (list1.isEmpty()) {
			String msg = "No Bookings on this date";
			model.setViewName("myError");
			model.addObject("msg", msg);
		} else {
			model = new ModelAndView("bydate");
			model.addObject("date", list1);
			return (model);
		}
		return model;
	}

	@RequestMapping("/viewroom")
	public ModelAndView viewAllRooms() {
		List<RoomBean> list = adminService.viewAllRooms();
		ModelAndView model = new ModelAndView();

		if (list.isEmpty()) {
			String msg = "No Rooms to Show";
			model.setViewName("myError");
			model.addObject("msg", msg);
		} else {
			model = new ModelAndView("roompage");
			model.addObject("roomlist", list);
			return (model);
		}
		return model;
	}

	@RequestMapping("/getAllRooms.obj")
	public ModelAndView getAllRooms(@RequestParam("hotel") String hotelId, @RequestParam("roomType") String roomType)
	{
		ModelAndView model=new ModelAndView();
		List<Object[]> listRooms=adminService.getAllRooms(hotelId,roomType);
		model.addObject("allRooms",listRooms);
		model.addObject("hotelId",hotelId);
		model.addObject("roomType",roomType);
		model.setViewName("showAllRooms");
		return model;
	}
	
	@RequestMapping("/deleteh")
	public ModelAndView deleteRoom(@RequestParam("hotelId") String hotelId) {
		List<HotelBean> bean = adminService.deleteRoom(hotelId);
		ModelAndView model = new ModelAndView("viewpage", "hotellist", bean);

		return (model);
	}
	

	@RequestMapping("/updateRoomType")
	public ModelAndView getRoomTypes(@RequestParam("hotel") String hotelId){
		ModelAndView model=new ModelAndView();
		List<Object[]> typeList=adminService.getType(hotelId);
		model.addObject("typeList",typeList);
		model.addObject("hotelId",hotelId);
		model.setViewName("RoomTypes");
		return model;
	}
	
	@RequestMapping("/updateRoomForm")
	public ModelAndView updateRoomForm(@RequestParam("hotel")String hotelId,@RequestParam("roomType")String roomType,@RequestParam("roomNo")String roomNo,@RequestParam("rate")double rate)
	{
		ModelAndView model=new ModelAndView();
		model.addObject("roomNo",roomNo);
		model.addObject("hotelId",hotelId);
		model.addObject("roomType",roomType);
		model.addObject("rate",rate);
		model.setViewName("UpdateRoom");
		return model;
	}
	@RequestMapping("/updateRoom")
	public ModelAndView updateRoom(String hotelId,String roomType,String roomNo,double rate)
	{
		ModelAndView model=new ModelAndView();
		List<Object[]> list=adminService.updateRoom(hotelId,roomType,roomNo,rate);
		model.addObject("allRooms",list);
		model.setViewName("redirect:/admin/Home.obj");
		return model;
	}

	@RequestMapping("Roomform")
	public String showRoomForm(){
		return "Roomform";
	}
	@RequestMapping("successroom")
	public ModelAndView addroom( @Valid RoomBean  roomBean,BindingResult result ){
		ModelAndView model= new ModelAndView();
		if(result.hasErrors()){
			model.setViewName("Roomform");
		}
		else{
			adminService.addRoom(roomBean);
			model.setViewName("redirect:/admin/Home.obj");
			//model.addObject("room", roomBean);
		}
		
		return model;
	}
	
}