package com.hbms.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hbms.bean.BookingBean;
import com.hbms.bean.HotelBean;
import com.hbms.exception.HbmsException;
import com.hbms.service.IUserCustomerService;

@Controller
@RequestMapping("customer")
public class UserCustomerController {

	 BookingBean bean=new BookingBean();
	@Autowired
	IUserCustomerService customerService;
	HotelBean hotelDetails;
	@RequestMapping("CustomerHome")
	public ModelAndView getAllHotels()
	{
		ModelAndView model=new ModelAndView();
		try{
		List<HotelBean>hlist=customerService.getAllHotels();
		model.addObject("hotelList",hlist);
		model.setViewName("customerHome");
		}
		catch(HbmsException e)
		{
			model.addObject("message","Could Not Fetch Hotel Details\nINTERNAL ERROR");
			model.setViewName("error");
		}
		return model;
	}
	@RequestMapping("getHotel")
	public ModelAndView getHotel(@RequestParam("id") String id)
	{
		ModelAndView model=new ModelAndView();
		try{
			hotelDetails=customerService.getHotel(id);
			List<Object[]> typeList=customerService.getType(id);
			model.addObject("hotelDetails",hotelDetails);
			model.addObject("typeList",typeList);
			model.setViewName("HotelDetails");
		}
		catch(HbmsException e){
			model.addObject("message","Could Not Fetch Hotel Details\nINTERNAL ERROR");
			model.setViewName("error");
		}
		return model;
	}
	@RequestMapping("bookType")
	public ModelAndView getNoOfRooms(@RequestParam("hotelId") String id,@RequestParam("type") String type)
	{
		ModelAndView model=new ModelAndView();
		try{
			hotelDetails=customerService.getHotel(id);
		long noOfRooms=customerService.getNoOfRooms(id,type);
		List<Object[]> details=customerService.getRoomDetails(id,type);
		model.addObject("hotelDetails",hotelDetails);
		model.addObject("type",type);
		model.addObject("roomsAvail",noOfRooms);
		model.addObject("roomDetails",details);
		
		model.setViewName("booking");
		}
		catch(HbmsException e)
		{
			model.addObject("message","Sorry User this Hotel has some technical issues in the selected Room Type");
			model.setViewName("error");
		}
		return model;
	}
	@RequestMapping("book")
	public ModelAndView book(@ModelAttribute("bookingForm") BookingBean bean, BindingResult result,@RequestParam("roomsBook") int roomsBook )
	{
		ModelAndView model=new ModelAndView();
		
		if(result.hasErrors())
		{
			model.addObject("message","Internal Error");
			model.setViewName("error");
		}
		else
		{
			try
			{
				List<BookingBean> bookingList=new ArrayList<BookingBean>();
				for(int i=0;i<roomsBook;i++)
				{
			BookingBean booking=customerService.bookRooms(bean);
			bookingList.add(booking);
				}
		
			hotelDetails=customerService.getHotel(bean.getHotelId());
			List<Object[]> details=customerService.getRoomDetails(bean.getHotelId(),bean.getRoomId());
			String name=customerService.getUsername(bean.getUserId());
			model.addObject("bookingDetails",bookingList);
			model.addObject("hotelDetails",hotelDetails);
			model.addObject("roomType",details);
			model.addObject("name",name);
			model.setViewName("BookingDetails");
			}
			catch(HbmsException e)
			{
				model.addObject("message","Unable to Book Rooms !! Internal Error");
				model.setViewName("error");
			}
		}
		return model;
	}
}
