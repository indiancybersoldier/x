package com.hbms.exception;

public class HbmsException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public HbmsException() {
		// TODO Auto-generated constructor stub
	}
	public HbmsException(String message)
	{
		super(message);
	}
}
