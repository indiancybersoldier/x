package com.hbms.dao;

import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hbms.bean.BookingBean;
import com.hbms.bean.HotelBean;
import com.hbms.bean.RoomBean;
import com.hbms.bean.UserBean;

@Repository
@Transactional
public class UserAdminDao implements IUserAdminDao {

	@PersistenceContext
	EntityManager emAdmin;
	UserBean beanUser = new UserBean();
	HotelBean beanHotel = new HotelBean();

	@Override
	public boolean addHotel(HotelBean hotelBean) {
		try {

			emAdmin.persist(hotelBean);
			return true;
		} catch (Exception e) {

			return false;
		}

	}

	@Override
	public void updatedes(HotelBean hotelId) {
		emAdmin.merge(hotelId);

	}

	@Override
	public HotelBean getHotelDetails(String hotelId) {

		return emAdmin.find(HotelBean.class, hotelId);
	}

	@Override
	public List<HotelBean> viewAllHotel() {
		TypedQuery<HotelBean> query = emAdmin.createQuery(
				"select hotel from HotelBean hotel", HotelBean.class);
		List<HotelBean> list = query.getResultList();

		return list;

	}

	@Override
	public HotelBean deletehotel(String hotelId) {
		HotelBean bean = emAdmin.find(HotelBean.class, hotelId);
		if (bean != null) {
			emAdmin.remove(bean);
		}
		return bean;
	}

	

	@Override
	public List<HotelBean> viewAllHotels() {
		// TODO Auto-generated method stub
		TypedQuery<HotelBean> query = emAdmin.createQuery("select shop from HotelBean shop order by hotelId",HotelBean.class);
        List<HotelBean> list=query.getResultList();
      
	    return list;
		
	}

	@Override
	public List<BookingBean> getBookingDetails(String id) {
		// TODO Auto-generated method stub
		TypedQuery<BookingBean> query = emAdmin.createQuery("from BookingBean where hotelId=?",BookingBean.class);
		query.setParameter(1,id);
        List<BookingBean> list=query.getResultList();
	    return list;
		
	}

	@Override
	public List<RoomBean> viewAllRooms() {
		// TODO Auto-generated method stub
		TypedQuery<RoomBean> query = emAdmin.createQuery(" from RoomBean",RoomBean.class);
	    List<RoomBean> list=query.getResultList();
	  
	    return list;
		
	}

	@Override
	public List<HotelBean> deleteRoom(String hotelId) {
		// TODO Auto-generated method stub
		beanHotel=emAdmin.find(HotelBean.class, hotelId);
		emAdmin.remove(beanHotel);
		TypedQuery<RoomBean>query=emAdmin.createQuery("Select r from RoomBean r where hotelId= :id",RoomBean.class);
		query.setParameter("id", hotelId);
		List<RoomBean> roomList=query.getResultList();
		
		for(RoomBean rList:roomList)
		{
			emAdmin.remove(rList);
		}
		List<HotelBean> hotelList=  viewAllHotels();
		
		return hotelList;
		
	}

	@Override
	public List<Object[]> viewGuest(String hotelId) {
		// TODO Auto-generated method stub
		 TypedQuery<Object[]> query = emAdmin.createQuery("SELECT b.userId,b.roomId,b.bookedFrom,b.bookedTo,b.noOfAdults,b.noOfChildren,b.roomNo from BookingBean b where b.hotelId=:id",Object[].class);
	        query.setParameter("id", hotelId);
	        List<Object[]> list=query.getResultList();
	        for(Object[] bList : list )
	        {
	        	beanUser=emAdmin.find(UserBean.class, bList[0]);
	        	bList[0]=beanUser.getUserName();
	        	
	        	TypedQuery<RoomBean> query1=emAdmin.createQuery("Select r from RoomBean r where r.roomId= :roomId", RoomBean.class);
	        	query1.setParameter("roomId", bList[1]);
	        	List<RoomBean>roomType=query1.getResultList();
	        	 for(RoomBean roomTypeList : roomType )
	         	bList[1]=roomTypeList.getRoomType();
	        	 
	    /*    	
	        	System.out.println(bList[0]+" "+bList[1]+" "+bList[2]+" "+bList[3]+" "+bList[4]+" "+bList[5]);*/
	        	
	        }
			/*TypedQuery<UserBean> query1 = emAdmin.createQuery("select userName from UserBean where userId=?",UserBean.class);
			query1.setParameter(1,id);

	        List<UserBean> list1=query1.getResultList();
	        list8.addAll(1,list);
	        list8.addAll(2,list1);
		    return list8;*/
	        return list;

		
	}

	@Override
	public List<Object[]> viewByDate(Date bookedFrom) {
		// TODO Auto-generated method stub
		TypedQuery<Object[]> query = emAdmin.createQuery("SELECT b.userId,b.roomNo,b.bookedFrom,b.bookedTo,b.noOfAdults,b.noOfChildren,b.hotelId from BookingBean b where b.bookedFrom=:id",Object[].class);
		 query.setParameter("id", bookedFrom);
	     List<Object[]> list=query.getResultList();
	     for(Object[] bList : list )
	     {
	     	beanUser=emAdmin.find(UserBean.class, bList[0]);
	     	bList[0]=beanUser.getUserName();
	     	beanHotel=emAdmin.find(HotelBean.class,bList[6]);
	     	bList[6]=beanHotel.getHotelName();
	     	System.out.println(bList[0]+" "+bList[1]+" "+bList[2]+" "+bList[3]+" "+bList[4]+" "+bList[5]+""+bList[6]);
	     }
		return list;
		
	}



	@Override
	public List<Object[]> getType(String hotelId) {
		// TODO Auto-generated method stub
		TypedQuery<Object[]> query=emAdmin.createQuery("SELECT r.roomType,r.roomId,r.photo FROM RoomBean As r where r.hotelId=:id group by r.roomType,r.roomId,r.photo ORDER BY r.roomId",Object[].class);
		query.setParameter("id", hotelId);
		List<Object[]> list= query.getResultList();
		
		return list;
	}

	@Override
	public List<Object[]> getAllRooms(String hotelId, String roomType) {
		// TODO Auto-generated method stub
		TypedQuery<Object[]> query=emAdmin.createQuery("Select p.roomType,p.roomNo,p.rate FROM RoomBean As p WHERE  p.hotelId=:id and p.roomId=:type", Object[].class);
		query.setParameter("id", hotelId);
		query.setParameter("type", roomType);
		List<Object[]> details=query.getResultList();
		return details;
	}

	@Override
	public List<Object[]> updateRoom(String hotelId, String roomType,
			String roomNo, double rate) {
		Query query=emAdmin.createQuery("Update RoomBean As p set p.rate=:rate WHERE  p.hotelId=:id and p.roomId=:type and p.roomNo=:roomNo");
		query.setParameter("roomNo", roomNo);
		query.setParameter("id", hotelId);
		query.setParameter("type", roomType);
		query.setParameter("rate", rate);
		query.executeUpdate();
		return getAllRooms(hotelId, roomType);
	}

	@Override
	public boolean addRoom(RoomBean roomBean) {
      try {
			
			emAdmin.persist(roomBean);
			return true;
		} catch (Exception e) {
			
			return false;	
		}

	}

	
}
