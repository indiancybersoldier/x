package com.hbms.dao;

import java.sql.Date;
import java.util.List;

import com.hbms.bean.BookingBean;
import com.hbms.bean.HotelBean;
import com.hbms.bean.RoomBean;

public interface IUserAdminDao {

	public List<Object[]> viewGuest(String hotelId);

	public List<Object[]> viewByDate(Date bookedFrom);

	public List<RoomBean> viewAllRooms();

	public List<HotelBean> deleteRoom(String hotelId);

	public List<HotelBean> viewAllHotels();

	public List<BookingBean> getBookingDetails(String id);

	public boolean addHotel(HotelBean hotelBean);

	public void updatedes(HotelBean hotelId);

	public HotelBean getHotelDetails(String hotelId);

	public List<HotelBean> viewAllHotel();

	public HotelBean deletehotel(String hotelId);

	public List<Object[]> getType(String hotelId);

	public List<Object[]> getAllRooms(String hotelId, String roomType);

	public List<Object[]> updateRoom(String hotelId, String roomType,
			String roomNo, double rate);

	public boolean addRoom(RoomBean roomBean);

}
