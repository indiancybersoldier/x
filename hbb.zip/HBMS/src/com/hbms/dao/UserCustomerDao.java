package com.hbms.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hbms.bean.BookingBean;
import com.hbms.bean.HotelBean;
import com.hbms.bean.RoomBean;
import com.hbms.bean.UserBean;
import com.hbms.exception.HbmsException;

@Repository
@Transactional
public class UserCustomerDao implements IUserCustomerDao{
	HotelBean hotelDetails=null;
	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	EntityManager emCustomer;

	@Override
	public List<HotelBean> getAllHotels() throws HbmsException {
		
		TypedQuery<HotelBean>query=emCustomer.createQuery("SELECT hd from HotelBean hd ORDER BY hotelName", HotelBean.class);
		
		List<HotelBean> list=query.getResultList();
		return list;
	}

	@Override
	public HotelBean getHotel(String id) throws HbmsException {
		// TODO Auto-generated method stub
		hotelDetails=emCustomer.find(HotelBean.class,id);
		return hotelDetails;
	}

	@Override
	public List<Object[]> getType(String id) throws HbmsException {
		// TODO Auto-generated method stub
		TypedQuery<Object[]> query=emCustomer.createQuery("SELECT r.roomType,r.roomId,r.photo FROM RoomBean As r where r.hotelId=:id and availability='Y' group by r.roomType,r.roomId,r.photo ORDER BY r.roomId",Object[].class);
		query.setParameter("id", id);
		List<Object[]> list= query.getResultList();
		
		return list;
	}

	@Override
	public long getNoOfRooms(String id, String type) throws HbmsException {
		// TODO Auto-generated method stub
		Query query=emCustomer.createQuery("SELECT COUNT(r.roomNo) FROM RoomBean r WHERE r.hotelId=:id and r.roomId=:type AND r.availability='Y'");
		query.setParameter("id", id);
		query.setParameter("type", type);
		return (long)query.getSingleResult();
		
	}

	@Override
	public List<Object[]> getRoomDetails(String id, String type)
			throws HbmsException {
		// TODO Auto-generated method stub
		TypedQuery<Object[]> query=emCustomer.createQuery("Select p.roomType,p.pernightrate,p.photo,p.roomNo FROM RoomBean As p WHERE  p.hotelId=:id and p.roomId=:type AND p.availability='Y'", Object[].class);
		query.setParameter("id", id);
		query.setParameter("type", type);
		List<Object[]> details=query.setMaxResults(1).getResultList();
		return details;
	}

	@Override
	public BookingBean bookRooms(BookingBean bean) throws HbmsException {
		// TODO Auto-generated method stub
		 final LocalDate firstDate = bean.getBookedFrom().toLocalDate();
	     final LocalDate secondDate = bean.getBookedTo().toLocalDate();
		 final long days=ChronoUnit.DAYS.between(firstDate,secondDate);
		 BookingBean bookingDetails=new BookingBean();
		 double rate=bean.getAmount();
		 String hotelId=bean.getHotelId();
		 String roomId=bean.getRoomId();
		 int numberOfAdults=bean.getNoOfAdults();
		 Date bookedFrom=bean.getBookedFrom();
		 Date bookedTo=bean.getBookedTo();
		 int noOfChildren=bean.getNoOfChildren();
		 bookingDetails.setBookedFrom(bookedFrom);
		 bookingDetails.setBookedTo(bookedTo);
		 bookingDetails.setHotelId(hotelId);
		 bookingDetails.setNoOfAdults(numberOfAdults);
		 bookingDetails.setNoOfChildren(noOfChildren);
		 bookingDetails.setRoomId(roomId);
		 bookingDetails.setUserId(bean.getUserId());
			bookingDetails.setAmount(rate*days);
			TypedQuery<RoomBean> query=emCustomer.createQuery("SELECT r from RoomBean r where hotelId=:hotelId and roomId=:roomId and availability='Y' order by roomNo", RoomBean.class);
			query.setParameter("hotelId", hotelId);
			query.setParameter("roomId", roomId);
			List<RoomBean> roomDetails=query.getResultList();
			for(RoomBean room: roomDetails)
			{
			bookingDetails.setRoomNo(room.getRoomNo());
			break;
			}
			
			Query query1=emCustomer.createQuery("Update RoomBean r set r.availability='N' where r.hotelId= :hotelId and r.roomId= :roomId and r.roomNo= :roomNo");
			query1.setParameter("hotelId", hotelId);
			query1.setParameter("roomId", roomId);
			query1.setParameter("roomNo", bookingDetails.getRoomNo());
			query1.executeUpdate();
			emCustomer.persist(bookingDetails);
			return bookingDetails;
		 }

	@Override
	public String getUsername(String userId) throws HbmsException {
		// TODO Auto-generated method stub
		
			UserBean user=emCustomer.find(UserBean.class, userId);
			return user.getUserName();
		
		
	}

}
