package com.hbms.dao;

import java.util.List;

import com.hbms.bean.UserBean;
import com.hbms.exception.HbmsException;


public interface IHotelMainDao {
	
	boolean registerCustomer(UserBean bean) throws HbmsException;
	public List<UserBean> validate(String id,String password) throws HbmsException;

}
