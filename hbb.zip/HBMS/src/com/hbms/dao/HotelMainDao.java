package com.hbms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hbms.bean.UserBean;
import com.hbms.exception.HbmsException;

@Repository
@Transactional
public class HotelMainDao  implements IHotelMainDao{

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public boolean registerCustomer(UserBean bean) throws HbmsException {
		try{
			entityManager.persist(bean);
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	@Override
	public List<UserBean> validate(String id,String password)  throws HbmsException
	{
		UserBean bean=null;
		
			String select = "Select u from UserBean u WHERE u.userId=:id and u.password=:pass";
			TypedQuery<UserBean> query=entityManager.createQuery(select, UserBean.class);
			query.setParameter("id", id);
			query.setParameter("pass", password);
			List<UserBean> list=query.getResultList();
			if(list.isEmpty())
			System.out.println("Sorry");
			
			for(UserBean b:list){
				System.out.println(b.getRole());
			}
			
			return list;
		 //bean=(UserBean) em.createQuery("SELECT userId,password FROM UserBean WHERE userId:userId AND password:passwor").getSingleResult();
		
		}
}

