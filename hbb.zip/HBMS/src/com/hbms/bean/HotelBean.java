package com.hbms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="HotelDetails")
public class HotelBean {
	@Id
	@Column(name="hotelId", length=4)
	private String hotelId;
	@Column(name="city", length=20)
	private String city;
	@Column(name="hotelName",length=20)
	private String hotelName;
	@Column(name="address",length=40)
	private String address;
	@Column(name="description",length=200)
	private String description;
	@Column(name="AVGRATEPERNIGHT")
	private double rate;
	@Column(name="phoneno1",length=10)
	private String mobileno;
	@Column(name="phoneno2",length=10)
	private String telephone;
	@Column(name="rating",length=4)
	private String rating;
	@Column(name="email",length=30)
	private String email;
	@Column(name="fax",length=15)
	private String fax;
	@Column(name="hotelImage")
	private String hotelImage;
	@Column(name="hotelInfo")
	private String hotelInfo;
	public HotelBean() {
		// TODO Auto-generated constructor stub
	}
	public HotelBean(String hotelId, String city, String hotelName,
			String address, String description, double rate, String mobileno,
			String telephone, String rating, String email, String fax,String hotelImage,String hotelInfo) {
		super();
		this.hotelId = hotelId;
		this.city = city;
		this.hotelName = hotelName;
		this.address = address;
		this.description = description;
		this.rate = rate;
		this.mobileno = mobileno;
		this.telephone = telephone;
		this.rating = rating;
		this.email = email;
		this.fax = fax;
		this.hotelImage=hotelImage;
		this.hotelInfo=hotelInfo;
	}
	public String getHotelId() {
		return hotelId;
	}
	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getHotelImage() {
		return hotelImage;
	}
	public void setHotelImage(String hotelImage) {
		this.hotelImage = hotelImage;
	}
	public String getHotelInfo() {
		return hotelInfo;
	}
	public void setHotelInfo(String hotelInfo) {
		this.hotelInfo = hotelInfo;
	}
}
