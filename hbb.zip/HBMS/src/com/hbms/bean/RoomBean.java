package com.hbms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="roomDetails")
public class RoomBean {
	@Id
	@Column(name="serial")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="bookingId")
	@SequenceGenerator(name="bookingId",sequenceName="sequence_booking")
	private int serial;
	@Column(name="hotelId")
	private String hotelId;
	@Column(name="roomId")
	private String roomId;
	@Column(name="roomNo")
	private String roomNo;
	@Column(name="roomType")
	private String roomType;
	@Column(name="pernightrate")
	private double rate;
	@Column(name="availability")
	private char availability;
	@Column(name="photo")
	private String photo;
	public int getSerial() {
		return serial;
	}
	public void setSerial(int serial) {
		this.serial = serial;
	}
	public String getHotelId() {
		return hotelId;
	}
	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}
	public String getRoomId() {
		return roomId;
	}
	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}
	public String getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public char getAvailability() {
		return availability;
	}
	public void setAvailability(char availability) {
		this.availability = availability;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public RoomBean(int serial, String hotelId, String roomId, String roomNo,
			String roomType, double rate, char availability, String photo) {
		super();
		this.serial = serial;
		this.hotelId = hotelId;
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.rate = rate;
		this.availability = availability;
		this.photo = photo;
	}
	public RoomBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
