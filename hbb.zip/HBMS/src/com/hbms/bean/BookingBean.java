package com.hbms.bean;




import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="bookingDetails")
public class BookingBean {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="bookingId")
	@SequenceGenerator(name="bookingId",sequenceName="sequence_booking")
	@Column(name="bookingId")
	private int bookingId;
	@Column(name="roomId")
	private String roomId;
	@Column(name="userId")
	private String userId;
	@Column(name="bookedFrom")
	private Date bookedFrom;
	@Column(name="bookedTo")
	private Date bookedTo;
	@Column(name="noOfAdults")
	private int noOfAdults;
	@Column(name="noOfChildren")
	private int noOfChildren;
	@Column(name="amount")
	private double amount;
	@Column(name="roomNo")
	private String roomNo;
	@Column(name="hotelId")
	private String hotelId;
	public BookingBean() {
		// TODO Auto-generated constructor stub
	}
	public BookingBean(int bookingId, String roomId, String userId,
			Date bookedFrom, Date bookedTo, int noOfAdults, int noOfChildren,
			double amount, String roomNo, String hotelId) {
		super();
		this.bookingId = bookingId;
		this.roomId = roomId;
		this.userId = userId;
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.amount = amount;
		this.roomNo = roomNo;
		this.hotelId = hotelId;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getRoomId() {
		return roomId;
	}
	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getBookedFrom() {
		return bookedFrom;
	}
	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}
	public Date getBookedTo() {
		return bookedTo;
	}
	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}
	public int getNoOfAdults() {
		return noOfAdults;
	}
	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}
	public int getNoOfChildren() {
		return noOfChildren;
	}
	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
	public String getHotelId() {
		return hotelId;
	}
	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}
	
	

}
