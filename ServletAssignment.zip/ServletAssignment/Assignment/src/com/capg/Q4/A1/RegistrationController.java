package com.capg.Q4.A1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class RegistrationValidator
 */
@WebServlet("/RegistrationController1")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserDTO udto;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String skills="";
		String skillSet[];
		udto=new UserDTO();
		udto.setfName(request.getParameter("fName"));
		udto.setlName(request.getParameter("lName"));
		udto.setpWord(request.getParameter("pWord"));
		udto.setGender(request.getParameter("gender"));
		
		skillSet=request.getParameterValues("skill");
		for(int i=0;i<skillSet.length;i++)
			skills+=skillSet[i];
		udto.setSkillSet(skills);
		udto.setCity(request.getParameter("city"));
		RegisterServiceImpl rsi=new RegisterServiceImpl(udto);
		if(rsi.op==0){
			RequestDispatcher rd=request.getRequestDispatcher("/Display.jsp");
			rd.forward(request, response);
		}
		else{
			RequestDispatcher rd=request.getRequestDispatcher("/Error.html");
			rd.forward(request, response);
		}
			
		
	}
	
	
}
