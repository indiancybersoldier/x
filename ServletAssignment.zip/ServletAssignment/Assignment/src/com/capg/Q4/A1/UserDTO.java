package com.capg.Q4.A1;

public class UserDTO {
	
private String fName;
private String lName;
private String pWord;
private String gender;
private String skillSet;
private String city;

public String getfName() {
	return fName;
}
public void setfName(String fName) {
	this.fName = fName;
}
public String getlName() {
	return lName;
}
public void setlName(String lName) {
	this.lName = lName;
}
public String getpWord() {
	return pWord;
}
public void setpWord(String pWord) {
	this.pWord = pWord;
}
public String getGender() {
	return gender;
}
public void setGender(String string) {
	this.gender = string;
}
public String getSkillSet() {
	return skillSet;
}
public void setSkillSet(String skillSet) {
	this.skillSet = skillSet;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}

	
}
