package com.capg.Q4.A1;

public class RegisterServiceImpl {

	int op;
	
	public RegisterServiceImpl(UserDTO udto)
	{
		
		new RegisterDAOImpl(udto);
		
	}
	public RegisterServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	public void getRedirect(int op)
	{
		this.op=op;
		
		
	}
}
