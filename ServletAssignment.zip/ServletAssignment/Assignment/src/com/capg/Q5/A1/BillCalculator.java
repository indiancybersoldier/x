package com.capg.Q5.A1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class BillCalculator
 */
@WebServlet("/BillCalculator")
public class BillCalculator extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BillCalculator() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		HttpSession session=request.getSession();
		EBillBean ebean=(EBillBean)session.getAttribute("bean");
		ebean.setLastMeterReading(Integer.parseInt(request.getParameter("lastReading")));
		ebean.setCurrentMeterReading(Integer.parseInt(request.getParameter("currentReading")));
		int fixedCharge=100;
		int lastReading=ebean.getLastMeterReading();
		int currentReading=ebean.getCurrentMeterReading();
		int unitsConsumed=currentReading-lastReading;
		double bill=unitsConsumed*1.15+fixedCharge;
		pw.write("Welcome "+ebean.getName());
		pw.write("<br>"
				+ "<h2>Electricity Bill for consumer no."+ebean.getConsumerNumber()+" "
						+ " <br>"
						+ "Consumed Unit :: "+unitsConsumed+""
								+ "<br>"
								+ "Net Amount "+bill);
	}

}
