package com.capg.Q5.A1;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.InitialContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

/**
 * Servlet implementation class EBillController
 */
@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       EBillBean billBean=new EBillBean();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(true);
		billBean.setConsumerNumber(Integer.parseInt(request.getParameter("conNumber")));
		billBean.setName(request.getParameter("name"));
		
		
		
		EBillServiceImpl ebillImpl=new EBillServiceImpl();
		int x=ebillImpl.EBillService(billBean);
		if(x==1)
		{
			RequestDispatcher rd=request.getRequestDispatcher("User_Info.html");
			rd.forward(request, response);
		}
		else{
			RequestDispatcher rd=request.getRequestDispatcher("Failed.html");
			rd.forward(request, response);
		}
		
		session.setAttribute("bean", billBean);
		
	}

}
