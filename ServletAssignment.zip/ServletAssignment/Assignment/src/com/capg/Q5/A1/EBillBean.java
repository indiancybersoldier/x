package com.capg.Q5.A1;

public class EBillBean {

	private int consumerNumber;
	private int lastMeterReading;
	private int currentMeterReading;
	private String name;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getConsumerNumber() {
		return consumerNumber;
	}
	public void setConsumerNumber(int consumerNumber) {
		this.consumerNumber = consumerNumber;
	}
	public int getLastMeterReading() {
		return lastMeterReading;
	}
	public void setLastMeterReading(int lastMeterReading) {
		this.lastMeterReading = lastMeterReading;
	}
	public int getCurrentMeterReading() {
		return currentMeterReading;
	}
	public void setCurrentMeterReading(int currentMeterReading) {
		this.currentMeterReading = currentMeterReading;
	}
	
}
