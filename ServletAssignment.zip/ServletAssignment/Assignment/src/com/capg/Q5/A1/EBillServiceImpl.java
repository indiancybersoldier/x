package com.capg.Q5.A1;

public class EBillServiceImpl {

	EBillBean billBean;
	public EBillServiceImpl() {
		// TODO Auto-generated constructor stub
		
	}

	public int EBillService(EBillBean billBean) {
		// TODO Auto-generated constructor stub
		this.billBean=billBean;
		int x=new EBillDAOImpl().validateLogin(billBean);
		return x;
	}
	
	

}
