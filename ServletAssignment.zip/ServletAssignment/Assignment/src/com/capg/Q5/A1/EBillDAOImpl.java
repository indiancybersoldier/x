package com.capg.Q5.A1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.naming.InitialContext;

import java.sql.ResultSet;

import javax.sql.DataSource;

public class EBillDAOImpl {

	
	public int validateLogin(EBillBean ebean)
	{
		int x=0;
		try{
			InitialContext inc=new InitialContext();
			DataSource ds=(DataSource)inc.lookup("java:jboss/datasources/ExampleDS");
			Connection con=ds.getConnection();
			System.out.println(con);
			System.out.println(ebean.getConsumerNumber());
			String query="select * from consumers where consumer_num="+ebean.getConsumerNumber();
			System.out.println(query);
			Statement ps=con.createStatement();
			System.out.println(ps);
			ResultSet rs=ps.executeQuery(query);
			System.out.println(rs);
			while(rs.next()){
			if((rs.getInt(1)==ebean.getConsumerNumber()) && (rs.getString(2).equals(ebean.getName())))
			{
				x=1;
			}
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return x;
	}
}
