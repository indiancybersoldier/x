package com.capg.Q3.A2;

public class RegisterServiceImpl {

	int op;
	
	public RegisterServiceImpl(UserDTO udto)
	{
		
		new RegisterDAOImpl(udto);
		
	}
	public RegisterServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	public void getRedirect(int op)
	{
		this.op=op;
		
		
	}
}
